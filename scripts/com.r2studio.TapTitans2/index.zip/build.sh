rm index.zip
zip index.zip index.js index.html images images/*
# adb push index.zip /sdcard/Robotmon/scripts/com.r2studio.TapTitans2/
# adb push i* /sdcard/Robotmon/scripts/com.r2studio.TapTitans2/
adb.windows push i* '//sdcard\Robotmon\scripts\com.r2studio.TapTitans2'