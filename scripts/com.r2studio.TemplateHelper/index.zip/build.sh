rm index.zip
zip index.zip index.js index.html images images/*
# adb push index.zip /sdcard/Robotmon/scripts/com.r2studio.TemplateHelper/
# adb push i* /sdcard/Robotmon/scripts/com.r2studio.TemplateHelper/
adb.windows push i* '//sdcard\Robotmon\scripts\com.r2studio.TemplateHelper'