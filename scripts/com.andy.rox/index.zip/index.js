/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 788:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function CocTask(config) {
  this.config = config;
  this.Const = {
    BtnCarnivalMenu: { x: 89, y: 138 },
    ColorNpcMsg: [
      { x: 592, y: 249, r: 167, g: 216, b: 255 },
      { x: 506, y: 249, r: 167, g: 218, b: 252 },
    ],
    BtnNpcMenu: { x: 549, y: 249 },
    BtnCloseMenu: { x: 616, y: 27 },
    BtnTaskType: [
      { x: 109, y: 292 },
      { x: 321, y: 292 },
      { x: 522, y: 292 },
    ],
    ColorDeliverMsg: [
      { x: 509, y: 178, r: 225, g: 247, b: 167 },
      { x: 588, y: 174, r: 222, g: 245, b: 171 },
    ],
    BtnPayMenu: { x: 549, y: 178 },
    BtnMoveToBuyItem_Have: [
      { x: 430, y: 135 },
      { x: 383, y: 79 },
      { x: 380, y: 126 },
    ],
    BtnMoveToBuyItem_NoHave: [
      { x: 505, y: 300 },
      { x: 278, y: 125 },
    ],
    ColorShopWindow: [
      { x: 261, y: 226, r: 121, g: 110, b: 113 },
      { x: 290, y: 226, r: 121, g: 110, b: 113 },
      { x: 457, y: 33, r: 249, g: 215, b: 113 },
      { x: 518, y: 31, r: 249, g: 215, b: 113 },
    ],
    ColorNeedBuy: [
      { x: 474, y: 303, r: 224, g: 230, b: 176 },
      { x: 540, y: 300, r: 223, g: 164, b: 81 },
    ],
    ColorPayBtn: [
      { x: 509, y: 305, r: 186, g: 198, b: 229 },
      { x: 478, y: 296, r: 187, g: 225, b: 247 },
      { x: 533, y: 296, r: 141, g: 187, b: 239 },
    ],
    BtnBuyItemFromNpc: [
      { x: 552, y: 246 },
      { x: 330, y: 135 },
      { x: 368, y: 175 },
      { x: 370, y: 217 },
      { x: 519, y: 310 },
      { x: 581, y: 23 },
    ],
    ColorIsCocitem: [
      { x: 547, y: 305, r: 141, g: 183, b: 235 },
      { x: 486, y: 310, r: 179, g: 214, b: 243 },
      { x: 569, y: 56, r: 211, g: 209, b: 211 },
      { x: 14, y: 54, r: 215, g: 217, b: 219 },
    ],
    ColorAcceptBtn: [
      { x: 82, y: 291, r: 151, g: 199, b: 239 },
      { x: 136, y: 291, r: 125, g: 153, b: 225 },
      { x: 290, y: 288, r: 158, g: 200, b: 241 },
      { x: 344, y: 288, r: 125, g: 155, b: 223 },
      { x: 498, y: 291, r: 161, g: 203, b: 243 },
      { x: 557, y: 291, r: 125, g: 153, b: 225 },
    ],
    ColorAcceptCocNpc: [
      { x: 549, y: 251, r: 91, g: 104, b: 112 },
      { x: 501, y: 251, r: 167, g: 218, b: 252 },
      { x: 602, y: 251, r: 175, g: 216, b: 254 },
    ],
    BuyItemCount: 30,
    TryTimes: 50,
  };
  this.handleCocEvents = [
    this.moveToCocNpc.bind(this),
    this.interactiveCocNpcDeliver.bind(this),
    this.interactiveCocNpcAcceptTask.bind(this),
    this.buyItemCoc.bind(this),
  ];
  this.init();
}

CocTask.prototype.init = function () {
  console.log("coc init");
  this.finish = false;
  this.eventsStage = 0;
};

// 交付任務
CocTask.prototype.interactiveCocNpcDeliver = function () {
  if (utils.isSameView(this.Const.ColorDeliverMsg)) {
    tap(this.Const.BtnPayMenu.x, this.Const.BtnPayMenu.y, this.config.sleep); //btn npc msg
    sleep(this.config.sleepAnimate * 3);
    if (utils.isSameView(this.Const.ColorPayBtn)) {
      //有部分道具
      tap(
        this.Const.ColorPayBtn[0].x,
        this.Const.ColorPayBtn[0].y,
        this.config.sleep
      );
      sleep(this.config.sleepAnimate * 3);
      if (utils.isSameView(this.Const.ColorPayBtn)) {
        utils.taps(this.Const.BtnMoveToBuyItem_Have);
      } else {
        console.log("one task finish");
        this.eventsStage = 0;
        return true;
      }
    } else if (utils.isSameView(this.Const.ColorNeedBuy)) {
      //完全沒有道具
      utils.taps(this.Const.BtnMoveToBuyItem_NoHave);
    } else {
      throw new Error("Coc task error");
    }
    return true;
  }
};

CocTask.prototype.autoCocTaskV2 = function () {
  console.log("autoCocTaskV2");
  if (this.finish) {
    console.log("Coc Task in finish state");
    return false;
  }
  var img = getScreenshot();
  for (var i = this.eventsStage; i < this.handleCocEvents.length; i++) {
    handler = this.handleCocEvents[i];
    var isAct = handler(img);
    if (isAct) {
      releaseImage(img);
      sleep(this.config.sleepAnimate);
      img = getScreenshot();
    }
  }
  releaseImage(img);
  return true;
};

CocTask.prototype.autoCocTask = function () {
  var result = true;
  this.moveToCocNpc();
  for (var i = 0; i < this.Const.TryTimes; i++) {
    if (utils.isSameView(this.Const.ColorNpcMsg)) {
      console.log("arrival Coc Npc");
      break;
    }
    console.log("wait walking to Coc Npc");
    sleep(5000);
  }
  if (i == this.Const.TryTimes) {
    console.log("move to Coc Npc error retry");
    return true;
  }

  if (utils.isSameView(this.Const.ColorDeliverMsg)) {
    //執行任務
    this.runTask();
  } //接任務
  else {
    result = this.acceptTask();
  }
  return result;
};

// 接受任次
CocTask.prototype.interactiveCocNpcAcceptTask = function () {
  var result = false;
  if (utils.isSameView(this.Const.ColorAcceptCocNpc)) {
    tap(this.Const.BtnNpcMenu.x, this.Const.BtnNpcMenu.y, this.config.sleep); //btn npc msg
    sleep(this.config.sleepAnimate * 4);
    tap(
      this.Const.BtnTaskType[this.config.cocTaskType].x,
      this.Const.BtnTaskType[this.config.cocTaskType].y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate * 4);
    if (utils.isSameView(this.Const.ColorAcceptBtn)) {
      console.log("cocTask Finish");
      this.finish = true;
    }
    tap(
      this.Const.BtnCloseMenu.x,
      this.Const.BtnCloseMenu.y,
      this.config.sleep
    );
    result = true;
    this.eventsStage = 0;
    sleep(this.config.sleepAnimate * 4);
  }
  return result;
};

CocTask.prototype.buyItemCoc = function () {
  var result = false;
  if (utils.isSameView(this.Const.ColorIsCocitem)) {
    tap(
      this.Const.ColorPayBtn[0].x,
      this.Const.ColorPayBtn[0].y,
      this.config.sleep
    );
    this.buyItems30FromCoc();
    this.eventsStage = 0;
    result = true;
  }
  if (utils.isSameView(this.Const.ColorShopWindow)) {
    utils.buyItems(this.Const.BuyItemCount);
    this.eventsStage = 0;
    result = true;
  }
  return result;
};

CocTask.prototype.buyItems30FromCoc = function () {
  utils.taps(this.Const.BtnBuyItemFromNpc);
};

CocTask.prototype.moveToCocNpc = function () {
  if (utils.inPageMain()) {
    utils.openCarnivalMenu(this.Const.BtnCarnivalMenu);
    this.eventsStage = 1;
    return true;
  }
  return false;
};

module.exports = CocTask;


/***/ }),

/***/ 255:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function DailyTaskManager(config) {
  this.config = config;
  this.isAcceptTask = false;
  this.isFinish = false;
  this.Const = {
    BtnCarnivalMenu: { x: 324, y: 234 },
    ButtonTaskListMoveTo: { x: 444, y: 497 },
    ButtonTaskList: { x: 10, y: 135 },
    ColorCheckBoard: [
      { x: 21, y: 300, r: 121, g: 114, b: 121 },
      { x: 77, y: 322, r: 123, g: 117, b: 125 },
      { x: 562, y: 317, r: 132, g: 127, b: 142 },
      { x: 612, y: 296, r: 121, g: 112, b: 117 },
      { x: 320, y: 7, r: 137, g: 112, b: 100 },
      { x: 337, y: 30, r: 116, g: 108, b: 116 },
      { x: 304, y: 30, r: 117, g: 109, b: 118 },
    ],
    BtnTaskNotePose: [
      { x: 113, y: 115, b: 146, g: 138, r: 138 },
      { x: 238, y: 127, b: 146, g: 138, r: 138 },
      { x: 356, y: 136, b: 146, g: 138, r: 138 },
      { x: 468, y: 135, b: 146, g: 138, r: 138 },
      { x: 559, y: 139, b: 146, g: 138, r: 138 },
      { x: 97, y: 230, b: 146, g: 138, r: 138 },
      { x: 204, y: 241, b: 146, g: 138, r: 138 },
      { x: 309, y: 246, b: 146, g: 138, r: 138 },
      { x: 419, y: 243, b: 146, g: 138, r: 138 },
      { x: 519, y: 268, b: 146, g: 138, r: 138 },
    ],
    BtnAccept: { x: 330, y: 284 },
    BtnEmpty: { x: 538, y: 30 },
    ColorAcceptBtn: [
      { x: 302, y: 286, r: 150, g: 200, b: 241 },
      { x: 354, y: 285, r: 125, g: 153, b: 224 },
    ],
    ColorGiveUpBtn: [
      { x: 297, y: 285, r: 240, g: 215, b: 134 },
      { x: 357, y: 283, r: 223, g: 161, b: 81 },
    ],
    BtnCloseBoard: { x: 606, y: 27 },
    ColorTaskPanelBtn: [
      { x: 15, y: 121, r: 243, g: 209, b: 178 },
      { x: 14, y: 155, r: 135, g: 122, b: 135 },
    ],
    ColorTaskPanelSwitchBtn: [
      { x: 16, y: 99, r: 128, g: 128, b: 128 },
      { x: 10, y: 100, r: 238, g: 228, b: 238 },
    ],
    BtnLeftTask: { x: 14, y: 138 },
    BtnTaskSwitch: { x: 14, y: 100 },
    TaskPanel: {
      top: 63,
      bottom: 275,
      left: 144,
      right: 206,
      moveSize: 1,
      taskColor: { r: 223, g: 150, b: 247 },
    },
    BtnMove: { x: 448, y: 300 },
    ColorNpcSkipMsg: [
      { x: 572, y: 18, r: 114, g: 97, b: 114 },
      { x: 577, y: 14, r: 117, g: 94, b: 113 },
    ],
    BtnSkipMsg: { x: 574, y: 18 },
    ColorNpcYellowMsg: [
      { x: 492, y: 250, r: 220, g: 245, b: 163 },
      { x: 492, y: 213, r: 252, g: 236, b: 170 },
      { x: 492, y: 183, r: 252, g: 236, b: 170 },
      { x: 492, y: 153, r: 252, g: 236, b: 170 },
    ],
    ColorNpcPay: [
      { x: 490, y: 304, r: 146, g: 196, b: 237 },
      { x: 536, y: 305, r: 125, g: 153, b: 224 },
    ],
    BtnNpcPay: { x: 511, y: 306 },
    ColorInteractive: { x: 431, y: 134, r: 242, g: 236, b: 218 }, // TODO　more color
    ColorTaskBoardFinish: [
      { x: 166, y: 157, r: 255, g: 255, b: 255 },
      { x: 419, y: 155, r: 255, g: 255, b: 255 },
      { x: 162, y: 203, r: 255, g: 255, b: 255 },
      { x: 473, y: 195, r: 255, g: 255, b: 255 },
    ],
    LeftTaskBoardPage: [
      { x: 122, y: 42, r: 192, g: 200, b: 217 },
      { x: 228, y: 39, r: 193, g: 193, b: 193 },
      { x: 340, y: 36, r: 121, g: 110, b: 113 },
      { x: 502, y: 37, r: 249, g: 249, b: 255 },
      { x: 115, y: 316, r: 211, g: 209, b: 211 },
      { x: 302, y: 314, r: 211, g: 209, b: 211 },
      { x: 501, y: 316, r: 211, g: 209, b: 211 },
    ],
  };
  this.init();
}
DailyTaskManager.prototype.init = function () {
  console.log("DailyTaskManager Init");
  this.isAcceptTask = false;
  this.isFinish = false;
};

DailyTaskManager.prototype.openTaskPanel = function () {
  console.log("OpenTaskPanel");
  if (utils.isSameView(this.Const.ColorTaskPanelSwitchBtn)) {
    tap(
      this.Const.BtnTaskSwitch.x,
      this.Const.BtnTaskSwitch.y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate);
  }
  tap(this.Const.BtnLeftTask.x, this.Const.BtnLeftTask.y, this.config.sleep);
  sleep(this.config.sleepAnimate * 2);
  if (!utils.isSameView(this.Const.LeftTaskBoardPage)) {
    tap(this.Const.BtnLeftTask.x, this.Const.BtnLeftTask.y, this.config.sleep);
    sleep(this.config.sleepAnimate * 2);
  }
};

DailyTaskManager.prototype.moveToTaskLocation = function () {
  console.log("moveToTaskLocation");
  var result = false;
  if (utils.isSameView(this.Const.LeftTaskBoardPage)) {
    var img = getScreenshot();
    var head = this.Const.TaskPanel.top;
    while (head < this.Const.TaskPanel.bottom) {
      head += this.Const.TaskPanel.moveSize;
      var c = getImageColor(img, this.Const.TaskPanel.left, head);
      if (utils.isSameColor(c, this.Const.TaskPanel.taskColor)) {
        result = true;
        tap(this.Const.TaskPanel.left, head, this.config.sleep);
        sleep(this.config.sleepAnimate);
        tap(this.Const.BtnMove.x, this.Const.BtnMove.y, this.config.sleep);
        sleep(this.config.sleepAnimate);
        break;
      }
    }
    releaseImage(img);
  }
  return result;
};

DailyTaskManager.prototype.doTaskV2 = function () {
  var handleEvents = [
    utils.isFollowing,
    utils.isLoading,
    this.firstAccept.bind(this),
    this.checkTaskBoardStatus.bind(this),
    this.payTaskItem.bind(this),
    this.npcSkipMsg.bind(this),
    this.moveToTaskLocation.bind(this),
    this.doInteractive.bind(this),
    utils.closeAutoBattle,
    this.openTaskPanel.bind(this), // need last Events
  ];
  var act = false;
  for (var i = 0; i < handleEvents.length; i++) {
    handler = handleEvents[i];
    var isAct = handler();
    if (isAct) {
      act = true;
      sleep(this.config.sleepAnimate);
      break;
    }
  }
  return act;
};

DailyTaskManager.prototype.doInteractiveFish = function () {};

DailyTaskManager.prototype.doInteractive = function () {
  if (utils.checkColor(this.Const.ColorInteractive)) {
    console.log("doInteractive");
    sleep(3000);
    if (utils.checkColor(this.Const.ColorInteractive)) {
      tap(
        this.Const.ColorInteractive.x,
        this.Const.ColorInteractive.y,
        this.config.sleep
      );
      sleep(this.config.sleepAnimate * 3);
      return true;
    }
  }
  return false;
};

DailyTaskManager.prototype.payTaskItem = function () {
  var result = false;
  for (var i in this.Const.ColorNpcYellowMsg) {
    if (utils.checkColor(this.Const.ColorNpcYellowMsg[i], 40)) {
      tap(
        this.Const.ColorNpcYellowMsg[i].x,
        this.Const.ColorNpcYellowMsg[i].y,
        this.config.sleep
      );
      sleep(3000);
      if (utils.isSameView(this.Const.ColorNpcPay)) {
        tap(this.Const.BtnNpcPay.x, this.Const.BtnNpcPay.y, this.config.sleep);
      }
      result = true;
    }
  }
  return result;
};

DailyTaskManager.prototype.npcSkipMsg = function () {
  if (utils.isSameView(this.Const.ColorNpcSkipMsg)) {
    tap(this.Const.BtnSkipMsg.x, this.Const.BtnSkipMsg.y, this.config.sleep);
    sleep(this.config.sleepAnimate * 2);
    return true;
  }
  return false;
};

DailyTaskManager.prototype.moveToTask = function () {
  utils.openCarnivalMenu(this.Const.BtnCarnivalMenu);
};

DailyTaskManager.prototype.checkTaskBoardStatus = function () {
  if (utils.isSameView(this.Const.ColorCheckBoard)) {
    console.log("in daily task board");
    this.acceptTask();
    return true;
  }
  return false;
};

DailyTaskManager.prototype.checkTaskFinish = function () {
  var result = utils.isSameView(this.Const.ColorTaskBoardFinish);
  console.log("Finish check ", result);
  return result;
};

DailyTaskManager.prototype.acceptTask = function () {
  console.log("acceptTask");
  var img = getScreenshot();
  for (var i = 0; i < this.Const.BtnTaskNotePose.length; ++i) {
    var c = getImageColor(
      img,
      this.Const.BtnTaskNotePose[i].x,
      this.Const.BtnTaskNotePose[i].y
    );
    if (utils.isSameColor(this.Const.BtnTaskNotePose[i], c)) {
      continue;
    }
    tap(
      this.Const.BtnTaskNotePose[i].x,
      this.Const.BtnTaskNotePose[i].y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate);
    if (utils.isSameView(this.Const.ColorAcceptBtn)) {
      tap(this.Const.BtnAccept.x, this.Const.BtnAccept.y, this.config.sleep);
      sleep(this.config.sleepAnimate);
    } else if (utils.isSameView(this.Const.ColorGiveUpBtn)) {
      tap(this.Const.BtnEmpty.x, this.Const.BtnEmpty.y, this.config.sleep);
      sleep(this.config.sleepAnimate);
    }
  }
  this.isAcceptTask = true;
  releaseImage(img);
  sleep(this.config.sleepAnimate * 8);
  this.isFinish = this.checkTaskFinish();
  this.closeBoard();
  return;
};

DailyTaskManager.prototype.firstAccept = function () {
  if (!this.isAcceptTask && utils.inPageMain()) {
    this.moveToTask();
    return true;
  }
  return false;
}

DailyTaskManager.prototype.closeBoard = function () {
  tap(
    this.Const.BtnCloseBoard.x,
    this.Const.BtnCloseBoard.y,
    this.config.sleep
  );
  sleep(3000);
};

DailyTaskManager.prototype.autoDailyTask = function () {
  if (this.isFinish) {
    console.log("Daily Task is already finished");
    return false;
  }

  this.doTaskV2();
  return true;
};

module.exports = DailyTaskManager;


/***/ }),

/***/ 660:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function FishManager(config) {
  this.config = config;
  this.Const = {
    ColorLifeIcon: [
      { x: 552, y: 260, r: 174, g: 188, b: 224 },
      { x: 563, y: 260, r: 236, g: 240, b: 248 },
      { x: 552, y: 245, r: 203, g: 162, b: 101 },
      { x: 562, y: 245, r: 161, g: 178, b: 105 },
    ],
    ColorFishStartBtn: [
      { x: 405, y: 151, r: 241, g: 234, b: 207 },
      { x: 395, y: 136, r: 215, g: 204, b: 109 },
    ],
    BtnFishStart: { x: 400, y: 141 },
    BtnExitFish: { x: 518, y: 86 },
    BtnBaitChange: { x: 440, y: 327 },
    BtnBaitPose: [
      { x: 300, y: 185 },
      { x: 342, y: 185 },
      { x: 392, y: 185 },
      { x: 300, y: 230 },
      { x: 344, y: 230 },
    ],
    BtnFishType: [
      { x: 117, y: 141, r: 235, g: 239, b: 247 },
      { x: 166, y: 143, r: 93, g: 175, b: 210 },
      { x: 214, y: 141, r: 88, g: 64, b: 39 },
      { x: 258, y: 139, r: 163, g: 214, b: 129 },
      { x: 113, y: 189, r: 247, g: 189, b: 181 },
      { x: 171, y: 185, r: 11, g: 58, b: 58 },
      { x: 212, y: 188, r: 208, g: 174, b: 157 },
      { x: 258, y: 190, r: 97, g: 98, b: 102 },
      { x: 117, y: 233, r: 98, g: 86, b: 64 },
      { x: 164, y: 232, r: 75, g: 68, b: 64 },
      { x: 218, y: 235, r: 97, g: 98, b: 102 },
      { x: 255, y: 233, r: 97, g: 98, b: 102 },
    ],
    ColorTaskFish: [
      { x: 389, y: 137, r: 212, g: 188, b: 109 },
      { x: 406, y: 137, r: 168, g: 151, b: 84 },
      { x: 390, y: 143, r: 252, g: 245, b: 244 },
      { x: 396, y: 149, r: 250, g: 243, b: 234 },
      { x: 396, y: 142, r: 244, g: 240, b: 218 },
      { x: 406, y: 145, r: 194, g: 152, b: 94 },
    ],
    ColorThrowRod: [
      { x: 562, y: 273, r: 229, g: 229, b: 253 },
      { x: 534, y: 246, r: 249, g: 233, b: 224 },
    ],
    ColorPullRod: { x: 567, y: 272, r: 207, g: 236, b: 160 },
    BtnPool: { x: 377, y: 178, r: 151, g: 165, b: 177 },
    TryTime: 50,
  };
  this.init();
}
FishManager.prototype.init = function () {
  console.log("FishManager Init");
};

FishManager.prototype.changeBait = function (index) {
  tap(
    this.Const.BtnBaitChange.x,
    this.Const.BtnBaitChange.y,
    this.config.sleep
  );
  sleep(3000);
  if (index >= this.Const.BtnBaitPose.length) {
    console.log("bait index out of range");
  } else {
    tap(
      this.Const.BtnBaitPose[index].x,
      this.Const.BtnBaitPose[index].y,
      this.config.sleep
    );
    sleep(3000);
    console.log("change bait :", index);
  }
  tap(
    this.Const.BtnBaitChange.x,
    this.Const.BtnBaitChange.y,
    this.config.sleep
  );
  sleep(3000);
};

FishManager.prototype.fish = function () {
  var start = false;
  if (utils.isSameView(this.Const.ColorThrowRod)) {
    tap(548, 240, 50);
    tap(548, 240, 50);
    start = true;
  }
  if (!start) {
    console.log("can not finish");
    return false;
  }
  sleep(this.config.sleepAnimate * 2);
  var done = false;
  for (var i = 0; i < 60; i++) {
    if (utils.checkColor(this.Const.ColorPullRod)) {
      tap(548, 240, 50);
      done = true;
      console.log("done");
    }
    sleep(150);
    if (done) {
      break;
    }
  }
  return done;
};

FishManager.prototype.autoFish = function () {
  utils.openLiveMenu("fish");
  console.log(
    "Fish :",
    "baitIndex ",
    this.config.baitIndex,
    "fishIndex ",
    this.config.fishIndex
  );
  tap(
    this.Const.BtnFishType[this.config.fishIndex].x,
    this.Const.BtnFishType[this.config.fishIndex].y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate);
  tap(this.Const.BtnPool.x, this.Const.BtnPool.y, this.config.sleep);
  sleep(this.config.sleepAnimate);

  for (var i = 0; i < this.Const.TryTime; i++) {
    if (utils.isSameView(this.Const.ColorTaskFish)) {
      console.log("arrival Pool");
      break;
    }
    console.log("wait walking to Pool");
    sleep(5000);
  }
  if (i == this.Const.TryTime) {
    console.log("error can not arrival Pool");
    return;
  }
  tap(
    this.Const.ColorTaskFish[0].x,
    this.Const.ColorTaskFish[0].y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate * 3);
  this.changeBait(this.config.baitIndex);
  for (var i = 0; i < this.config.fishTimes; i++) {
    console.log("start finishing...");
    var act = this.fish();
    if (!act) {
      break;
    }
    sleep(5000);
    console.log("finish done", i + 1);
  }
  tap(this.Const.BtnExitFish.x, this.Const.BtnExitFish.y, this.config.sleep);
  console.log("exit finishing...");
  sleep(3000);
};

module.exports = FishManager;


/***/ }),

/***/ 288:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function GardeningManager(config) {
  this.config = config;
  this.Const = {
    BtnPlantType: [
      { x: 118, y: 139, r: 184, g: 163, b: 194 },
      { x: 167, y: 138, r: 164, g: 164, b: 164 },
      { x: 206, y: 138, r: 169, g: 121, b: 135 },
      { x: 256, y: 140, r: 142, g: 122, b: 162 },
      { x: 112, y: 189, r: 142, g: 149, b: 166 },
      { x: 162, y: 190, r: 71, g: 237, b: 237 },
      { x: 215, y: 187, r: 43, g: 36, b: 105 },
      { x: 257, y: 189, r: 56, g: 43, b: 37 },
      { x: 116, y: 237, r: 51, g: 37, b: 30 },
      { x: 156, y: 237, r: 64, g: 72, b: 81 },
      { x: 219, y: 238, r: 27, g: 27, b: 71 },
      { x: 266, y: 237, r: 36, g: 36, b: 69 },
      { x: 114, y: 279, r: 90, g: 84, b: 86 },
      { x: 165, y: 282, r: 20, g: 13, b: 75 },
      { x: 226, y: 286, r: 97, g: 98, b: 102 },
      { x: 260, y: 286, r: 77, g: 67, b: 78 },
    ],
    ColorTaskGardening: [
      { x: 392, y: 144, r: 242, g: 233, b: 222 },
      { x: 398, y: 137, r: 243, g: 236, b: 211 },
      { x: 404, y: 148, r: 246, g: 243, b: 231 },
      { x: 396, y: 150, r: 212, g: 196, b: 163 },
      { x: 394, y: 145, r: 252, g: 252, b: 235 },
    ],
    ColorGardeningRuning: [
      {x: 261, y: 237, r: 91, g: 86, b: 119},
      {x: 253, y: 246, r: 108, g: 105, b: 129},
      {x: 259, y: 247, r: 99, g: 103, b: 114},
    ],
    ColorVerificationWindow: [
      {x: 293, y: 250, r: 151, g: 199, b: 239},
      {x: 347, y: 248, r: 128, g: 153, b: 226},
      {x: 222, y: 125, r: 195, g: 195, b: 206},
      {x: 425, y: 125, r: 184, g: 192, b: 208},
      {x: 223, y: 162, r: 255, g: 208, b: 213},
    ],
    BtnLoc: { x: 380, y: 179, r: 250, g: 250, b: 251 },
    BtnStartMining: { x: 556, y: 268, r: 219, g: 214, b: 230 },
  };
  this.init();
}

GardeningManager.prototype.autoGardening = function () {
  console.log(
    "Gardening :",
    "plantIndex ",
    this.config.plantIndex,
    "gardeningTimes",
    this.config.gardeningTimes,
    "DoTimes",
    this.DoTimes
  );

  if (utils.isSameView(this.Const.ColorVerificationWindow))
  {
    // console.log("wait 90 sec");
    // sleep(90000); //遇到驗證視窗 等待90s
    console.log("gardening Fail by Verification Window");
    this.init();
    return false;
  }
  else if (this.DoTimes >= this.config.gardeningTimes) {
    this.init();
    return false;
  } else if (!utils.isStop() || utils.isLoading()) {
    sleep(this.config.sleepAnimate * 2);
    return true;
  } else if (utils.isSameView(this.Const.ColorTaskGardening) && utils.checkColor(this.Const.ColorTaskGardening[0])) {
    tap(
      this.Const.ColorTaskGardening[0].x,
      this.Const.ColorTaskGardening[0].y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate);
    if (!utils.isSameView(this.Const.ColorGardeningRuning))
    { 
        console.log("gardening Fail");
        this.init();
        return false;
    }
    sleep(this.config.sleepAnimate * 6); //5sec
    this.DoTimes++;
  } else {
    utils.openLiveMenu("gardening");
    tap(
      this.Const.BtnPlantType[this.config.plantIndex].x,
      this.Const.BtnPlantType[this.config.plantIndex].y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate);
    tap(this.Const.BtnLoc.x, this.Const.BtnLoc.y, this.config.sleep);
    sleep(this.config.sleepAnimate);
  }
  return true;
};

GardeningManager.prototype.init = function () {
  console.log("Gardening init");
  this.DoTimes = 0;
};

module.exports = GardeningManager;


/***/ }),

/***/ 322:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function GuildTask(config) {
  this.config = config;
  this.selectItem = 0;
  this.Const = {
    BtnCarnivalMenu: { x: 520, y: 183 },
    BtnGuildMenu: [
      { x: 278, y: 60 },
      { x: 188, y: 157 },
    ],
    BtnMoveToNpc: [
      { x: 377, y: 76 },
      { x: 377, y: 118 },
    ],
    ColorShopWindow: [
      { x: 261, y: 226, r: 121, g: 110, b: 113 },
      { x: 290, y: 226, r: 121, g: 110, b: 113 },
      { x: 457, y: 33, r: 249, g: 215, b: 113 },
      { x: 518, y: 31, r: 249, g: 215, b: 113 },
    ],
    ColorGuildMenu: [
      { x: 82, y: 47, r: 135, g: 100, b: 67 },
      { x: 192, y: 43, r: 170, g: 131, b: 85 },
      { x: 420, y: 43, r: 166, g: 131, b: 89 },
      { x: 510, y: 43, r: 117, g: 92, b: 68 },
      { x: 539, y: 315, r: 139, g: 105, b: 93 },
      { x: 441, y: 312, r: 146, g: 110, b: 101 },
      { x: 220, y: 312, r: 140, g: 108, b: 95 },
    ],
    BtnFinishTask: { x: 334, y: 227 },
    BuyItemCount: 50,
    ColorExchangeMenu: [
      { x: 75, y: 46, r: 125, g: 179, b: 239 },
      { x: 109, y: 46, r: 113, g: 163, b: 229 },
      { x: 75, y: 66, r: 115, g: 164, b: 230 },
      { x: 113, y: 65, r: 113, g: 163, b: 229 },
    ],
    BuyItemFromExchangeState1: [
      { x: 268, y: 120 },
      { x: 204, y: 296 },
    ],
    BuyItemFromExchangeState2: [
      { x: 268, y: 60 }, // Change page
      { x: 547, y: 106 }, // receive
      { x: 579, y: 25 }, // close
    ],
    ColorFinishBtn: [
      //ToDo get color info
      { x: 309, y: 230, r: 133, g: 227, b: 94 },
      { x: 361, y: 231, r: 107, g: 176, b: 71 },
    ],
    BtnCloseMenu: [
      { x: 571, y: 43 },
      { x: 578, y: 21 },
    ],
    BtnGardening: [
      { x: 398, y: 144, r: 249, g: 246, b: 235 },
      { x: 400, y: 137, r: 239, g: 227, b: 190 },
      { x: 411, y: 140, r: 220, g: 171, b: 98 },
      { x: 386, y: 141, r: 230, g: 200, b: 96 },
      { x: 399, y: 152, r: 250, g: 232, b: 226 },
    ],
    BtnItemPaper: [
      { x: 159, y: 101, r: 244, g: 236, b: 227 },
      { x: 282, y: 105, r: 243, g: 223, b: 190 },
      { x: 404, y: 101, r: 243, g: 223, b: 190 },
      { x: 529, y: 105, r: 243, g: 223, b: 190 },
    ],
    BtnItemIcon: [
      { x: 122, y: 123, r: 143, g: 122, b: 101 },
      { x: 238, y: 126, r: 235, g: 239, b: 247 },
      { x: 360, y: 116, r: 235, g: 239, b: 247 },
      { x: 493, y: 123, r: 162, g: 179, b: 111 },
    ],
    GardeningTimes: 5,
  };
  this.handleGuildEvents = [
    this.openGuildPanel.bind(this),
    this.selectTaskItem.bind(this),
    this.getTaskItem.bind(this),
  ];
  this.init();
}

GuildTask.prototype.init = function () {
  console.log("GuildTask init");
  this.selectItem = 0;
  this.finish = false;
  this.eventsStage = 0;
};

GuildTask.prototype.autoGuildTaskV2 = function () {
  console.log("autoGuildTask");
  if (this.finish) {
    console.log("Guild Task in finish state");
    return false;
  }
  var img = getScreenshot();
  for (var i = this.eventsStage; i < this.handleGuildEvents.length; i++) {
    handler = this.handleGuildEvents[i];
    var isAct = handler(img);
    if (isAct) {
      releaseImage(img);
      sleep(this.config.sleepAnimate);
      img = getScreenshot();
    }
  }
  releaseImage(img);
  return true;
};

GuildTask.prototype.selectTaskItem = function () {
  if (utils.isSameView(this.Const.ColorGuildMenu)) {
    tap(
      this.Const.BtnItemPaper[this.selectItem].x,
      this.Const.BtnItemPaper[this.selectItem].y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate);
    tap(
      this.Const.BtnFinishTask.x,
      this.Const.BtnFinishTask.y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate * 2);
    // check task is finish
    if (!utils.isSameView(this.Const.ColorFinishBtn)) {
      console.log("autoGuild Finish");
      utils.taps(this.Const.BtnCloseMenu);
      this.finish = true;
    }
    tap(
      this.Const.BtnItemIcon[this.selectItem].x,
      this.Const.BtnItemIcon[this.selectItem].y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate * 4);
    utils.taps(this.Const.BtnMoveToNpc, this.config.sleep);
    return true;
  }
  return false;
};

GuildTask.prototype.autoGuildTask = function () {
  console.log("autoGuildTask");
  if (!utils.isSameView(this.Const.ColorGuildMenu)) {
    this.openGuildPanel();
  }
  tap(
    this.Const.BtnItemPaper[this.selectItem].x,
    this.Const.BtnItemPaper[this.selectItem].y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate);
  tap(
    this.Const.BtnFinishTask.x,
    this.Const.BtnFinishTask.y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate);
  if (!utils.isSameView(this.Const.ColorFinishBtn)) {
    console.log("autoGuild Finish");
    utils.taps(this.Const.BtnCloseMenu);
    return false;
  }
  tap(
    this.Const.BtnItemIcon[this.selectItem].x,
    this.Const.BtnItemIcon[this.selectItem].y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate * 4);
  utils.taps(this.Const.BtnMoveToNpc, this.config.sleep);
  this.getTaskItem();
  return true;
};

GuildTask.prototype.getTaskItem = function () {
  var result = false;
  if (utils.isSameView(this.Const.ColorExchangeMenu)) {
    console.log("交易行購買");
    if (this.config.useCrystalToBuy) {
      utils.taps(this.Const.BuyItemFromExchangeState1, this.config.sleep);
      sleep(6000); // wait for Exchange Buy
      utils.taps(this.Const.BuyItemFromExchangeState2, this.config.sleep);
      utils.checkInMainPage();
      result = true;
    } else {
      this.selectItem = (this.selectItem + 1) % this.Const.BtnItemIcon.length;
      console.log("this.selectItem : ", this.selectItem);
      utils.checkInMainPage();
      result = true;
    }
  } else if (utils.isSameView(this.Const.ColorShopWindow)) {
    console.log("一般商人購買");
    utils.buyItems(this.Const.BuyItemCount);
    result = true;
  } else if (utils.isSameView(this.Const.BtnGardening)) {
    console.log("園藝獲得(若園藝等級不足 超過嘗試次數將會放棄執行任務");
    if (this.config.guildTaskUseGardening) {
      for (var j = 0; j < 5; j++) {
        tap(
          this.Const.BtnGardening[0].x,
          this.Const.BtnGardening[0].y,
          this.config.sleep
        );
        sleep(this.config.sleepAnimate * 5);
      }
      result = true;
    } else {
      this.selectItem = (this.selectItem + 1) % this.Const.BtnItemIcon.length;
      console.log("this.selectItem : ", this.selectItem);
      utils.checkInMainPage();
      result = true;
    }
  }
  sleep(this.config.sleepAnimate * 3);
  if (result) {
    this.eventsStage = 0;
  }
  return result;
};

GuildTask.prototype.openGuildPanel = function () {
  if (utils.inPageMain()) {
    if (!utils.isSameView(this.Const.ColorGuildMenu)) {
      console.log("openGuildPanel");
      utils.openCarnivalMenu(this.Const.BtnCarnivalMenu);
      utils.taps(this.Const.BtnGuildMenu, this.config.sleepAnimate * 5);
      this.eventsStage = 1;
      return true;
    }
  }
  return false;
};

module.exports = GuildTask;


/***/ }),

/***/ 832:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function Login(config) {
  this.config = config;
  this.Const = {
    ColorPhoneDesktop: [
      { x: 25, y: 50, r: 15, g: 9, b: 6 },
      { x: 32, y: 268, r: 8, g: 0, b: 5 },
      { x: 603, y: 82, r: 7, g: 2, b: 5 },
      { x: 616, y: 269, r: 10, g: 22, b: 68 },
    ],
    ColorCloseNewsBtn: [
      { x: 565, y: 27, r: 247, g: 128, b: 162 },
      { x: 566, y: 37, r: 249, g: 249, b: 255 },
    ],
    ColorInGame: [
      { x: 8, y: 292, r: 255, g: 255, b: 255 },
      { x: 25, y: 331, r: 240, g: 245, b: 255 },
      { x: 615, y: 122, r: 255, g: 255, b: 255 },
      { x: 58, y: 348, r: 202, g: 202, b: 206 },
    ],
    ColorPageNews: [
      { x: 566, y: 37, r: 249, g: 249, b: 255 },
      { x: 308, y: 37, r: 255, g: 255, b: 255 },
      { x: 529, y: 37, r: 255, g: 255, b: 255 },
      { x: 327, y: 316, r: 255, g: 251, b: 245 },
      { x: 554, y: 308, r: 247, g: 247, b: 251 },
    ],
    pageInit: [
      { x: 25, y: 11, r: 234, g: 233, b: 247 },
      { x: 25, y: 20, r: 216, g: 215, b: 244 },
      { x: 26, y: 55, r: 187, g: 185, b: 213 },
      { x: 24, y: 70, r: 200, g: 191, b: 241 },
      { x: 617, y: 11, r: 217, g: 201, b: 227 },
      { x: 617, y: 48, r: 218, g: 206, b: 220 },
      { x: 623, y: 59, r: 109, g: 142, b: 200 },
      { x: 617, y: 95, r: 109, g: 142, b: 200 },
    ],
    pageInitDone: [
      { x: 25, y: 11, r: 234, g: 233, b: 247 },
      { x: 25, y: 20, r: 216, g: 215, b: 244 },
      { x: 26, y: 55, r: 187, g: 185, b: 213 },
      { x: 24, y: 70, r: 200, g: 191, b: 241 },
      { x: 617, y: 11, r: 217, g: 201, b: 227 },
      { x: 617, y: 48, r: 218, g: 206, b: 220 },
      { x: 623, y: 59, r: 109, g: 142, b: 200 },
      { x: 617, y: 95, r: 109, g: 142, b: 200 },
      { x: 338, y: 247, r: 255, g: 255, b: 255 },
      { x: 358, y: 258, r: 158, g: 179, b: 227 },
      { x: 321, y: 270, r: 221, g: 227, b: 245 },
    ],
    regions: [
      { x: 171, y: 137, r: 212, g: 220, b: 249 },
      { x: 173, y: 178, r: 128, g: 146, b: 223 },
      { x: 173, y: 213, r: 121, g: 140, b: 216 },
      { x: 170, y: 254, r: 124, g: 143, b: 220 },
      { x: 170, y: 294, r: 120, g: 145, b: 216 },
    ],
    servers: [
      { x: 261, y: 85, r: 229, g: 233, b: 244 },
      { x: 439, y: 85, r: 230, g: 234, b: 242 },
      { x: 261, y: 131, r: 229, g: 232, b: 242 },
      { x: 438, y: 131, r: 232, g: 233, b: 238 },
      { x: 258, y: 177, r: 233, g: 235, b: 243 },
      { x: 444, y: 177, r: 230, g: 232, b: 237 },
      { x: 258, y: 221, r: 233, g: 234, b: 238 },
      { x: 439, y: 223, r: 230, g: 231, b: 237 },
    ],
    okRoles: [
      { x: 544, y: 59, r: 184, g: 241, b: 113 },
      { x: 544, y: 131, r: 185, g: 241, b: 113 },
      { x: 543, y: 205, r: 187, g: 241, b: 113 },
    ],
    pageChoseRoles: [
      { x: 19, y: 22, r: 235, g: 229, b: 227 },
      { x: 35, y: 22, r: 231, g: 231, b: 239 },
      { x: 27, y: 27, r: 162, g: 165, b: 181 },
      { x: 25, y: 325, r: 251, g: 155, b: 155 },
      { x: 38, y: 320, r: 255, g: 219, b: 219 },
      { x: 39, y: 334, r: 255, g: 221, b: 221 },
    ],
    // create role
    pageCreatingRole: [
      { x: 26, y: 29, r: 165, g: 168, b: 182 },
      { x: 485, y: 35, r: 98, g: 166, b: 243 },
      { x: 594, y: 33, r: 107, g: 154, b: 245 },
      { x: 546, y: 63, r: 227, g: 233, b: 239 },
      { x: 541, y: 199, r: 226, g: 233, b: 240 },
      { x: 506, y: 321, r: 165, g: 206, b: 240 },
      { x: 572, y: 320, r: 127, g: 153, b: 224 },
      { x: 259, y: 320, r: 194, g: 78, b: 78 },
    ],
    pageConfirmLogin: [
      { x: 319, y: 225, r: 48, g: 116, b: 238 },
      { x: 193, y: 114, r: 255, g: 255, b: 255 },
      { x: 187, y: 261, r: 255, g: 255, b: 255 },
      { x: 444, y: 255, r: 255, g: 255, b: 255 },
      { x: 443, y: 125, r: 255, g: 255, b: 255 },
      { x: 410, y: 148, r: 245, g: 246, b: 248 },
    ],
    pageInGameNews: [
      { x: 587, y: 45, r: 255, g: 255, b: 255 },
      { x: 588, y: 54, r: 198, g: 87, b: 127 },
      { x: 377, y: 42, r: 255, g: 255, b: 255 },
      { x: 254, y: 44, r: 228, g: 198, b: 170 },
    ],
    tryTimes: 100,
  };
  this.handleNews = utils.makeSimpleHandler(
    "handleNews",
    this.Const.ColorPageNews,
    this.Const.ColorPageNews[0].x,
    this.Const.ColorPageNews[0].y
  );
  this.init();
}

Login.prototype.init = function () {
  console.log("login init");
};

Login.prototype.handleROInit = function (img) {
  if (utils.isSameView(this.Const.pageInit, img)) {
    console.log(
      "handleROInit",
      "region",
      this.config.region,
      "server",
      this.config.server
    );
    // Run over all servers
    for (var i = 0; i < 10; i++) {
      sleep(this.config.sleepAnimate * 2);
      if (!utils.isSameView(this.Const.pageInitDone)) {
        continue;
      }
      if (this.config.region != -1) {
        tap(338, 256, this.config.sleep); // select server
        sleep(this.config.sleepAnimate * 3);
        this.findEmptyServer();
      } else {
        tap(320, 315, this.config.sleep);
        sleep(this.config.sleepAnimate * 3);
      }
      break;
    }
    return true;
  }
  return false;
};

Login.prototype.handleConfirmLogin = function () {
  if (utils.isSameView(this.Const.pageConfirmLogin)) {
    tap(
      this.Const.pageConfirmLogin[0].x,
      this.Const.pageConfirmLogin[0].y,
      this.config.sleep
    );
  }
};

Login.prototype.handleInGameNews = function () {
  if (utils.isSameView(this.Const.pageInGameNews)) {
    tap(
      this.Const.pageInGameNews[0].x,
      this.Const.pageInGameNews[0].y,
      this.config.sleep
    );
  }
};

Login.prototype.handleChoseRoles = function () {
  if (utils.isSameView(this.Const.pageChoseRoles)) {
    console.log("handleChoseRoles : ", this.config.runRoles);
    var img = getScreenshot();
    var c = getImageColor(
      img,
      this.Const.okRoles[this.config.runRoles].x,
      this.Const.okRoles[this.config.runRoles].y
    );
    if (!utils.isSameColor(this.Const.okRoles[this.config.runRoles], c)) {
      tap(
        this.Const.okRoles[this.config.runRoles].x,
        this.Const.okRoles[this.config.runRoles].y,
        this.config.sleep
      );
      sleep(this.config.sleepAnimate * 3);
      tap(320, 320, this.config.sleep);
      tap(320, 320, this.config.sleep);
      console.log(
        "handleChoseRoles choice, sleep 20 secs",
        this.config.runRoles
      );
      sleep(20000);
      releaseImage(img);
      this.handleCreatingRole();
      return true;
    } else {
      console.log("select roles : ", this.config.runRoles);
      tap(
        this.Const.okRoles[this.config.runRoles].x,
        this.Const.okRoles[this.config.runRoles].y,
        this.config.sleep
      );
      tap(320, 320, this.config.sleep);
      releaseImage(img);
      sleep(this.config.sleepAnimate * 3);
      return true;
    }
    /*releaseImage(img);
    tap(29, 29,  this.config.sleep);
    console.log("NoEmptyRoles back, sleep 6 secs");
    sleep(6000);
    return true;*/
  }
  return false;
};

Login.prototype.handleCreatingRole = function (img) {
  if (utils.isSameView(this.Const.pageCreatingRole, img)) {
    console.log("handleCreatingRole");
    for (var i = 0; i < 12; i++) {
      tap(261, 320, this.config.sleep);
      sleep(this.config.sleepAnimate * 2);
      tap(362, 322, this.config.sleep);
      sleep(this.config.sleepAnimate * 2);
      tap(362, 322, this.config.sleep);
      sleep(this.config.sleepAnimate * 2);
      // type some random words
      typing("X" + Math.ceil(Math.random() * 1000), 1000);
      tap(591, 323, this.config.sleep);

      sleep(this.config.sleepAnimate * 2);
      tap(550, 327, this.config.sleep);
      sleep(this.config.sleepAnimate * 2);
      tap(550, 327, this.config.sleep);
      sleep(2 * 1000);
      if (utils.inPageMain()) {
        break;
      }
    }
    return true;
  }
  return false;
};

Login.prototype.handleInitThings = function () {
  var handleEvents = [
    this.handleNews,
    this.handleConfirmLogin.bind(this),
    this.handleROInit.bind(this),
    this.handleChoseRoles.bind(this),
    this.handleCreatingRole.bind(this),
    this.handleInGameNews.bind(this),
    utils.checkChatWindow,
  ];
  sleep(this.config.sleepAnimate);
  var act = false;
  var img = getScreenshot();
  // check whether dialog popup
  for (var i = 0; i < handleEvents.length; i++) {
    handler = handleEvents[i];
    var isAct = handler(img);
    if (isAct) {
      act = true;
      releaseImage(img);
      sleep(this.config.sleepAnimate);
      img = getScreenshot();
    }
  }
  releaseImage(img);
  return act;
};

Login.prototype.checkLaunchGame = function () {
  var whSize = getScreenSize();
  if (whSize.width === 360) {
    console.log("Start RO");
    // NOX
    execute(
      "BOOTCLASSPATH=/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar am start -n com.play.rogt/com.Ro.Ro.UnityPlayerActivity"
    );
    // LDPlayer
    execute('ANDROID_DATA=/data BOOTCLASSPATH=/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar am start -n com.play.rogt/com.Ro.Ro.UnityPlayerActivity');
    // MEmu
    execute(
      'ANDROID_DATA=/data BOOTCLASSPATH=/system/framework/core-oj.jar:/system/framework/core-libart.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/ims-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/apache-xml.jar:/system/framework/org.apache.http.legacy.boot.jar am start -n com.play.rogt/com.Ro.Ro.UnityPlayerActivity'
    );
    // sleep(30 * 1000);
    return true;
  } else {
    console.log("whSize :", JSON.stringify(whSize));
    return false;
  }
};

Login.prototype.findEmptyServer = function () {
  console.log("findEmptyServer", this.config.region, this.config.server);
  for (var r = this.config.region; r < this.Const.regions.length; r++) {
    var region = this.Const.regions[r];
    tap(region.x, region.y, this.config.sleep);
    tap(region.x, region.y, this.config.sleep);
    sleep(this.config.sleepAnimate * 2);
    for (var s = this.config.server; s < this.Const.servers.length; s++) {
      var server = this.Const.servers[s];
      this.config.server++;
      var img = getScreenshot();
      var c = getImageColor(img, server.x, server.y);
      var ok = utils.isSameColor(server, c, 10);
      releaseImage(img);
      if (ok) {
        tap(server.x, server.y, this.config.sleep);
        tap(server.x, server.y, this.config.sleep);
        sleep(this.config.sleepAnimate * 2);
        sleep(this.config.sleepAnimate * 2);
        tap(325, 315, this.config.sleep); // go in server
        tap(325, 315, this.config.sleep); // go in server
        console.log("goto server sleep 16 secs", r, s);
        sleep(16000);
        this.handleChoseRoles();
        return true;
      }
    }
    this.config.region++;
    this.config.server = 0;
  }
  return false;
};

Login.prototype.loginGame = function () {
  console.log("loginGame");
  for (var i = 0; i < 100; i++) {
    console.log("wait game loading...");
    if (utils.inPageMain()) {
      sleep(this.config.sleepAnimate * 5);
      if (utils.inPageMain()) {
        sleep(this.config.sleepAnimate * 5);
        break;
      }
    }
    this.handleInitThings();
    sleep(5000);
  }
  console.log("loginGame end");
};

Login.prototype.autoLogin = function () {
  console.log("autoLogin");
  var act = this.checkLaunchGame();
  console.log("autoLogin act :", act);
  if (act) {
    this.loginGame();
  }
};

module.exports = Login;


/***/ }),

/***/ 698:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function Lvling(config) {
  this.config = config;
  this.startTime = 0;
  this.isLvling = false;
  this.Const = {
    BtnMonsterLabel: { x: 579, y: 119, r: 187, g: 85, b: 85 },
    BtnAuto: [
      { x: 408, y: 264 },
      { x: 557, y: 174 },
    ],
    BtnInAuto: [
      { x: 402, y: 271, r: 224, g: 238, b: 249 },
      { x: 415, y: 271, r: 209, g: 237, b: 252 },
      { x: 409, y: 263, r: 224, g: 238, b: 246 },
      { x: 409, y: 275, r: 107, g: 202, b: 255 },
      { x: 409, y: 271, r: 64, g: 170, b: 241 },
    ],
    BtnMonster: { x: 273, y: 125 },
    BtnNextPage: { x: 541, y: 180, r: 157, g: 171, b: 191 },
    BtnMonsterPose: [
      { x: 137, y: 93, r: 255, g: 183, b: 191 },
      { x: 208, y: 93, r: 89, g: 95, b: 61 },
      { x: 275, y: 94, r: 138, g: 86, b: 100 },
      { x: 137, y: 159, r: 241, g: 241, b: 241 },
      { x: 206, y: 157, r: 186, g: 186, b: 186 },
      { x: 278, y: 157, r: 181, g: 181, b: 181 },
      { x: 139, y: 222, r: 117, g: 117, b: 117 },
      { x: 204, y: 224, r: 226, g: 176, b: 126 },
      { x: 280, y: 228, r: 217, g: 217, b: 217 },
      { x: 139, y: 289, r: 42, g: 42, b: 42 },
      { x: 209, y: 291, r: 114, g: 97, b: 80 },
      { x: 276, y: 289, r: 71, g: 71, b: 71 },
      { x: 364, y: 94, r: 139, g: 96, b: 49 },
      { x: 433, y: 93, r: 246, g: 180, b: 231 },
      { x: 496, y: 96, r: 54, g: 50, b: 50 },
      { x: 362, y: 155, r: 253, g: 189, b: 99 },
      { x: 437, y: 158, r: 119, g: 102, b: 153 },
      { x: 504, y: 161, r: 94, g: 94, b: 94 },
      { x: 368, y: 223, r: 93, g: 59, b: 42 },
      { x: 428, y: 226, r: 201, g: 201, b: 201 },
      { x: 494, y: 223, r: 228, g: 76, b: 110 },
      { x: 360, y: 291, r: 128, g: 94, b: 162 },
      { x: 425, y: 294, r: 143, g: 143, b: 160 },
      { x: 502, y: 292, r: 163, g: 163, b: 163 },
    ],
    BtnMoveToMonster: { x: 427, y: 224, r: 139, g: 155, b: 168 },
    TryTimes: 50,
  };
  this.init();
}

Lvling.prototype.init = function () {
  console.log("Lvling Init");
};

Lvling.prototype.autoLvling = function () {
  if (utils.isSameView(this.Const.BtnInAuto)) {
    console.log("isLvling");
    if (Date.now() - this.startTime > this.config.lvlingTime) {
      tap(this.Const.BtnAuto[0].x, this.Const.BtnAuto[0].y, this.config.sleep);
      sleep(this.config.sleepAnimate);
      console.log("finish Lvling");
      return false;
    }
  } else {
    utils.openStudentManual();
    tap(
      this.Const.BtnMonsterLabel.x,
      this.Const.BtnMonsterLabel.y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate * 2);
    var pageIndex = parseInt(
      this.config.monsterIndex / this.Const.BtnMonsterPose.length
    );
    var poseIndex = parseInt(
      this.config.monsterIndex % this.Const.BtnMonsterPose.length
    );
    console.log("pageIndex ", pageIndex, "poseIndex ", poseIndex);
    for (var i = 0; i < pageIndex; ++i) {
      tap(
        this.Const.BtnNextPage.x,
        this.Const.BtnNextPage.y,
        this.config.sleep
      );
      sleep(this.config.sleepAnimate * 6);
    }
    tap(
      this.Const.BtnMonsterPose[poseIndex].x,
      this.Const.BtnMonsterPose[poseIndex].y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate * 2);
    tap(
      this.Const.BtnMoveToMonster.x,
      this.Const.BtnMoveToMonster.y,
      this.config.sleep
    );
    sleep(this.config.sleepAnimate * 2);
    var followerCount = 0;
    for (var i = 0; i < this.Const.TryTimes; ++i) {
      if (!utils.isStop() || utils.isLoading()) {
        followerCount = 0;
      } else {
        followerCount += 1;
      }
      if (followerCount > 2) {
        break;
      }
      console.log("wait walking followerCount : ", followerCount);
      sleep(5000);
    }
    if (i == this.Const.TryTimes) {
      console.log("can not move to living loc");
      return false;
    }
    tap(this.Const.BtnAuto[0].x, this.Const.BtnAuto[0].y, this.config.sleep);
    sleep(3000);
    tap(this.Const.BtnAuto[1].x, this.Const.BtnAuto[1].y, this.config.sleep);
    if (Date.now() - this.startTime > this.config.lvlingTime * 60 * 1000) {
      this.startTime = Date.now();
    }
  }
  sleep(this.Const.sleepAnimate * 10);
  return true;
};

module.exports = Lvling;


/***/ }),

/***/ 900:
/***/ (function(module) {

var gConfig;
var cbtnTaskMenus = [
  { x: 169, y: 102, r: 251, g: 233, b: 154 }, // yellow top
  { x: 174, y: 125, r: 240, g: 238, b: 243 },
];
var cbtnTaskDialogConfirms = [{ x: 609, y: 251, r: 254, g: 237, b: 199 }];
var cbtnDialogSkip = { x: 591, y: 22, r: 29, g: 50, b: 87 };
var cbtnAttackEmpty = { x: 548, y: 264, r: 127, g: 160, b: 197 };
var cbtnTakePicture = { x: 436, y: 202, r: 244, g: 246, b: 251 };
var cbtnAttack = { x: 578, y: 303, r: 255, g: 119, b: 170 };

var regions = [
  { x: 171, y: 137, r: 212, g: 220, b: 249 },
  { x: 173, y: 178, r: 128, g: 146, b: 223 },
  { x: 173, y: 213, r: 121, g: 140, b: 216 },
  { x: 170, y: 254, r: 124, g: 143, b: 220 },
  { x: 170, y: 294, r: 120, g: 145, b: 216 },
];
var servers = [
  { x: 261, y: 85, r: 229, g: 233, b: 244 },
  { x: 439, y: 85, r: 230, g: 234, b: 242 },
  { x: 261, y: 131, r: 229, g: 232, b: 242 },
  { x: 438, y: 131, r: 232, g: 233, b: 238 },
  { x: 258, y: 177, r: 233, g: 235, b: 243 },
  { x: 444, y: 177, r: 230, g: 232, b: 237 },
  { x: 258, y: 221, r: 233, g: 234, b: 238 },
  { x: 439, y: 223, r: 230, g: 231, b: 237 },
];
var okRoles = [
  { x: 544, y: 59, r: 184, g: 241, b: 113 },
  { x: 544, y: 131, r: 185, g: 241, b: 113 },
  { x: 543, y: 205, r: 187, g: 241, b: 113 },
];

var pageNews = [
  { x: 566, y: 37, r: 249, g: 249, b: 255 },
  { x: 308, y: 37, r: 255, g: 255, b: 255 },
  { x: 529, y: 37, r: 255, g: 255, b: 255 },
  { x: 327, y: 316, r: 255, g: 251, b: 245 },
  { x: 554, y: 308, r: 247, g: 247, b: 251 },
];
var pageInit = [
  { x: 25, y: 11, r: 234, g: 233, b: 247 },
  { x: 25, y: 20, r: 216, g: 215, b: 244 },
  { x: 26, y: 55, r: 187, g: 185, b: 213 },
  { x: 24, y: 70, r: 200, g: 191, b: 241 },
  { x: 617, y: 11, r: 217, g: 201, b: 227 },
  { x: 617, y: 48, r: 218, g: 206, b: 220 },
  { x: 623, y: 59, r: 109, g: 142, b: 200 },
  { x: 617, y: 95, r: 109, g: 142, b: 200 },
];
var pageInitDone = [
  { x: 25, y: 11, r: 234, g: 233, b: 247 },
  { x: 25, y: 20, r: 216, g: 215, b: 244 },
  { x: 26, y: 55, r: 187, g: 185, b: 213 },
  { x: 24, y: 70, r: 200, g: 191, b: 241 },
  { x: 617, y: 11, r: 217, g: 201, b: 227 },
  { x: 617, y: 48, r: 218, g: 206, b: 220 },
  { x: 623, y: 59, r: 109, g: 142, b: 200 },
  { x: 617, y: 95, r: 109, g: 142, b: 200 },
  { x: 338, y: 247, r: 255, g: 255, b: 255 },
  { x: 358, y: 258, r: 158, g: 179, b: 227 },
  { x: 321, y: 270, r: 221, g: 227, b: 245 },
];

var pageDialog = [
  { x: 228, y: 281, r: 234, g: 234, b: 234 },
  { x: 436, y: 283, r: 233, g: 233, b: 233 },
  { x: 133, y: 339, r: 227, g: 220, b: 238 },
  { x: 523, y: 337, r: 227, g: 221, b: 235 },
];

var pageMakeEnforceItem = [
  { x: 363, y: 310, r: 134, g: 170, b: 236 },
  { x: 229, y: 41, r: 221, g: 197, b: 180 },
  { x: 372, y: 45, r: 224, g: 199, b: 192 },
  { x: 460, y: 50, r: 138, g: 140, b: 143 },
  { x: 605, y: 50, r: 155, g: 115, b: 119 },
];

var pageQuitDialog = [
  { x: 338, y: 105, r: 121, g: 110, b: 113 },
  { x: 290, y: 232, r: 223, g: 152, b: 88 },
  { x: 397, y: 232, r: 125, g: 153, b: 227 },
  { x: 448, y: 113, r: 232, g: 109, b: 148 },
  { x: 316, y: 150, r: 231, g: 231, b: 235 },
];

var pageTask = [
  { x: 473, y: 301, r: 223, g: 156, b: 85 },
  { x: 432, y: 41, r: 194, g: 194, b: 203 },
  { x: 215, y: 41, r: 197, g: 197, b: 205 },
  { x: 337, y: 38, r: 121, g: 110, b: 113 },
  { x: 503, y: 38, r: 249, g: 249, b: 255 },
];

var pageTaskInit = [
  { x: 109, y: 109, r: 233, g: 233, b: 244 },
  { x: 101, y: 262, r: 234, g: 234, b: 248 },
  { x: 289, y: 132, r: 233, g: 233, b: 245 },
  { x: 429, y: 116, r: 255, g: 255, b: 255 },
  { x: 533, y: 93, r: 224, g: 216, b: 208 },
  { x: 483, y: 236, r: 247, g: 245, b: 243 },
];

var cbtnTaskAddFriend = { x: 573, y: 123, r: 123, g: 144, b: 101 };
// var cbtnTaskAddFriendClose = { x: 606, y: 25, r: 249, g: 249, b: 255 };
var pageTaskAddFriend = [
  { x: 484, y: 60, r: 125, g: 108, b: 105 },
  { x: 583, y: 120, r: 167, g: 208, b: 125 },
  { x: 410, y: 321, r: 231, g: 231, b: 235 },
  { x: 519, y: 321, r: 129, g: 153, b: 226 },
  { x: 614, y: 26, r: 244, g: 153, b: 178 },
];

var pageTaskPretendDead = [
  { x: 547, y: 229, r: 141, g: 184, b: 217 },
  { x: 392, y: 227, r: 226, g: 216, b: 231 },
  { x: 478, y: 228, r: 223, g: 210, b: 231 },
  { x: 538, y: 222, r: 239, g: 239, b: 255 },
  { x: 549, y: 223, r: 103, g: 123, b: 156 },
  { x: 559, y: 229, r: 112, g: 161, b: 197 },
  { x: 541, y: 238, r: 232, g: 238, b: 242 },
  { x: 553, y: 238, r: 200, g: 220, b: 230 },
];
var pageTaskPretendDead2 = [
  { x: 550, y: 226, r: 98, g: 115, b: 147 },
  { x: 541, y: 230, r: 133, g: 180, b: 214 },
  { x: 504, y: 268, r: 220, g: 226, b: 206 },
  { x: 599, y: 213, r: 220, g: 226, b: 205 },
  { x: 482, y: 19, r: 110, g: 127, b: 209 },
  { x: 612, y: 251, r: 255, g: 255, b: 255 },
];

var pageTaskAddHP = [
  { x: 504, y: 272, r: 202, g: 215, b: 152 },
  { x: 346, y: 268, r: 226, g: 215, b: 231 },
  { x: 438, y: 268, r: 222, g: 210, b: 231 },
  { x: 493, y: 262, r: 121, g: 155, b: 65 },
  { x: 504, y: 262, r: 211, g: 221, b: 167 },
  { x: 514, y: 264, r: 164, g: 181, b: 114 },
  { x: 516, y: 272, r: 168, g: 197, b: 102 },
];

var pageAutoAttacking = [
  { x: 410, y: 265, r: 198, g: 232, b: 248 },
  { x: 412, y: 267, r: 127, g: 214, b: 253 },
  { x: 417, y: 271, r: 199, g: 238, b: 244 },
  { x: 404, y: 271, r: 191, g: 241, b: 248 },
  { x: 410, y: 277, r: 179, g: 234, b: 250 },
];

var pageTaskDialogGiveSomething = [
  { x: 494, y: 251, r: 225, g: 248, b: 172 },
  { x: 80, y: 341, r: 227, g: 219, b: 236 },
  { x: 560, y: 343, r: 227, g: 219, b: 237 },
  { x: 613, y: 252, r: 210, g: 238, b: 160 },
  { x: 314, y: 284, r: 235, g: 233, b: 235 },
];

var pageTaskDialogMakeSomething = [
  { x: 496, y: 251, r: 199, g: 223, b: 254 },
  { x: 606, y: 251, r: 186, g: 223, b: 254 },
  { x: 320, y: 282, r: 233, g: 233, b: 233 },
  { x: 83, y: 342, r: 227, g: 219, b: 236 },
  { x: 545, y: 344, r: 227, g: 219, b: 236 },
];

var pageTaskDialogMakeSomething2 = [
  { x: 602, y: 217, r: 249, g: 233, b: 173 },
  { x: 496, y: 251, r: 199, g: 223, b: 254 },
  { x: 606, y: 251, r: 186, g: 223, b: 254 },
  { x: 320, y: 282, r: 233, g: 233, b: 233 },
  { x: 83, y: 342, r: 227, g: 219, b: 236 },
  { x: 545, y: 344, r: 227, g: 219, b: 236 },
];
var pageTaskDialogMakeSomething3 = [
  { x: 609, y: 175, r: 249, g: 232, b: 164 },
  { x: 610, y: 216, r: 168, g: 208, b: 255 },
  { x: 611, y: 248, r: 179, g: 220, b: 252 },
  { x: 318, y: 284, r: 233, g: 233, b: 233 },
  { x: 156, y: 339, r: 227, g: 220, b: 235 },
  { x: 521, y: 340, r: 227, g: 219, b: 236 },
];
var pageTaskDialogMakeSomething4 = [
  { x: 605, y: 183, r: 168, g: 209, b: 252 },
  { x: 605, y: 216, r: 174, g: 209, b: 251 },
  { x: 605, y: 249, r: 167, g: 208, b: 254 },
  { x: 350, y: 282, r: 229, g: 229, b: 229 },
  { x: 270, y: 342, r: 227, g: 219, b: 236 },
  { x: 470, y: 340, r: 227, g: 219, b: 236 },
];
var pageTaskDialogMakeSomething5 = [
  { x: 608, y: 147, r: 249, g: 232, b: 164 },
  { x: 611, y: 184, r: 160, g: 201, b: 250 },
  { x: 610, y: 215, r: 167, g: 208, b: 255 },
  { x: 610, y: 250, r: 167, g: 208, b: 255 },
  { x: 341, y: 281, r: 229, g: 229, b: 229 },
  { x: 233, y: 341, r: 227, g: 219, b: 236 },
  { x: 471, y: 340, r: 227, g: 219, b: 236 },
];
var pageTaskDialogMakeSomething6 = [
  { x: 608, y: 251, r: 234, g: 233, b: 240 },
  { x: 254, y: 282, r: 233, g: 233, b: 233 },
  { x: 430, y: 281, r: 234, g: 234, b: 234 },
  { x: 234, y: 344, r: 227, g: 217, b: 239 },
  { x: 470, y: 343, r: 227, g: 219, b: 236 },
];

var pageTaskTransferCheck = [
  { x: 60, y: 247, r: 173, g: 213, b: 244 },
  { x: 60, y: 255, r: 150, g: 200, b: 241 },
  { x: 116, y: 257, r: 126, g: 153, b: 227 },
  { x: 116, y: 249, r: 124, g: 152, b: 222 },
  { x: 10, y: 348, r: 50, g: 56, b: 112 },
  { x: 629, y: 349, r: 60, g: 67, b: 119 },
  { x: 619, y: 239, r: 77, g: 81, b: 152 },
];

var pageTaskTransfer = [
  { x: 37, y: 139, r: 79, g: 130, b: 216 },
  { x: 41, y: 139, r: 82, g: 138, b: 231 },
  { x: 45, y: 139, r: 78, g: 128, b: 213 },
  { x: 49, y: 139, r: 75, g: 118, b: 192 },
  { x: 484, y: 18, r: 112, g: 128, b: 211 },
  { x: 434, y: 20, r: 234, g: 207, b: 193 },
  { x: 489, y: 19, r: 145, g: 227, b: 254 },
];

var pageTaskTransferLicense = [
  { x: 420, y: 58, r: 247, g: 247, b: 243 },
  { x: 549, y: 60, r: 247, g: 247, b: 243 },
  { x: 432, y: 117, r: 255, g: 255, b: 255 },
  { x: 441, y: 258, r: 247, g: 245, b: 243 },
  { x: 544, y: 258, r: 247, g: 239, b: 239 },
];

var pageTaskSelectBrew = [
  { x: 365, y: 195, r: 235, g: 239, b: 247 },
  { x: 484, y: 195, r: 235, g: 239, b: 247 },
  { x: 388, y: 228, r: 152, g: 200, b: 239 },
  { x: 444, y: 228, r: 125, g: 153, b: 225 },
];

var pageCheckSomething = [
  { x: 424, y: 129, r: 204, g: 189, b: 101 },
  { x: 435, y: 129, r: 239, g: 227, b: 190 },
  { x: 443, y: 131, r: 173, g: 138, b: 78 },
  { x: 443, y: 138, r: 192, g: 147, b: 104 },
  { x: 433, y: 137, r: 254, g: 247, b: 232 },
  { x: 425, y: 137, r: 207, g: 178, b: 128 },
];

var pageCheckSomething2 = [
  { x: 426, y: 122, r: 212, g: 203, b: 77 },
  { x: 432, y: 126, r: 252, g: 252, b: 235 },
  { x: 444, y: 128, r: 179, g: 153, b: 76 },
  { x: 430, y: 133, r: 184, g: 160, b: 107 },
  { x: 425, y: 142, r: 194, g: 158, b: 82 },
  { x: 440, y: 142, r: 237, g: 229, b: 196 },
];
var pageCheckSomething3 = [
  { x: 419, y: 184, r: 214, g: 194, b: 88 },
  { x: 441, y: 184, r: 178, g: 149, b: 74 },
  { x: 436, y: 195, r: 239, g: 227, b: 190 },
  { x: 424, y: 202, r: 198, g: 150, b: 82 },
  { x: 446, y: 203, r: 193, g: 139, b: 82 },
];
var pageCheckSomething4 = [
  { x: 426, y: 122, r: 216, g: 212, b: 81 },
  { x: 440, y: 124, r: 182, g: 169, b: 78 },
  { x: 436, y: 133, r: 239, g: 227, b: 190 },
  { x: 444, y: 139, r: 199, g: 155, b: 87 },
  { x: 424, y: 141, r: 207, g: 169, b: 94 },
  { x: 419, y: 133, r: 212, g: 194, b: 96 },
];
var pageCheckSomething4 = [
  { x: 426, y: 122, r: 216, g: 212, b: 81 },
  { x: 440, y: 124, r: 182, g: 169, b: 78 },
  { x: 436, y: 133, r: 239, g: 227, b: 190 },
  { x: 444, y: 139, r: 199, g: 155, b: 87 },
  { x: 424, y: 141, r: 207, g: 169, b: 94 },
  { x: 419, y: 133, r: 212, g: 194, b: 96 },
];
var pageCheckSomething5 = [
  { x: 423, y: 181, r: 249, g: 242, b: 182 },
  { x: 434, y: 182, r: 211, g: 189, b: 88 },
  { x: 445, y: 185, r: 195, g: 153, b: 84 },
  { x: 450, y: 195, r: 189, g: 144, b: 84 },
  { x: 436, y: 197, r: 239, g: 227, b: 190 },
  { x: 425, y: 200, r: 197, g: 169, b: 85 },
  { x: 444, y: 202, r: 230, g: 202, b: 170 },
];

var pageCheckSomething6 = [
  { x: 423, y: 124, r: 249, g: 239, b: 178 },
  { x: 437, y: 125, r: 247, g: 247, b: 230 },
  { x: 443, y: 128, r: 180, g: 148, b: 112 },
  { x: 443, y: 137, r: 195, g: 148, b: 111 },
  { x: 433, y: 133, r: 240, g: 229, b: 195 },
  { x: 418, y: 133, r: 193, g: 177, b: 119 },
  { x: 421, y: 142, r: 186, g: 154, b: 115 },
];

var pageCheckSomething7 = [
  { x: 424, y: 123, r: 248, g: 232, b: 184 },
  { x: 444, y: 126, r: 174, g: 143, b: 98 },
  { x: 428, y: 133, r: 227, g: 215, b: 219 },
  { x: 442, y: 135, r: 190, g: 144, b: 98 },
  { x: 421, y: 138, r: 186, g: 145, b: 84 },
  { x: 439, y: 142, r: 240, g: 232, b: 207 },
];
var pageCheckSomething8 = [
  { x: 431, y: 135, r: 238, g: 228, b: 195 },
  { x: 423, y: 126, r: 198, g: 185, b: 83 },
  { x: 439, y: 126, r: 250, g: 250, b: 233 },
  { x: 421, y: 135, r: 173, g: 147, b: 71 },
  { x: 432, y: 142, r: 239, g: 229, b: 197 },
  { x: 438, y: 138, r: 202, g: 167, b: 129 },
];

// pointer
var pageCheckSomething9 = [
  { x: 430, y: 128, r: 252, g: 245, b: 240 },
  { x: 426, y: 132, r: 254, g: 249, b: 248 },
  { x: 424, y: 134, r: 255, g: 246, b: 229 },
  { x: 434, y: 134, r: 241, g: 233, b: 203 },
  { x: 432, y: 136, r: 249, g: 245, b: 229 },
  { x: 438, y: 140, r: 249, g: 248, b: 239 },
];
// magi
var pageCheckSomething10 = [
  { x: 426, y: 126, r: 252, g: 252, b: 234 },
  { x: 436, y: 128, r: 251, g: 249, b: 239 },
  { x: 430, y: 140, r: 249, g: 249, b: 241 },
  { x: 432, y: 148, r: 171, g: 156, b: 151 },
  { x: 438, y: 140, r: 252, g: 251, b: 234 },
  { x: 434, y: 152, r: 161, g: 144, b: 138 },
];

// hand
var pageCheckSomething11 = [
  { x: 440, y: 126, r: 250, g: 250, b: 233 },
  { x: 438, y: 134, r: 252, g: 244, b: 227 },
  { x: 424, y: 140, r: 255, g: 247, b: 239 },
  { x: 436, y: 140, r: 248, g: 243, b: 229 },
  { x: 434, y: 142, r: 247, g: 241, b: 226 },
  { x: 436, y: 148, r: 222, g: 214, b: 210 },
  { x: 436, y: 150, r: 252, g: 252, b: 252 },
  { x: 436, y: 154, r: 253, g: 252, b: 252 },
  { x: 436, y: 152, r: 253, g: 253, b: 253 },
];
// read point
var pageCheckSomething12 = [
  { x: 438, y: 193, r: 237, g: 227, b: 192 },
  { x: 430, y: 186, r: 249, g: 237, b: 228 },
  { x: 434, y: 190, r: 236, g: 228, b: 195 },
  { x: 440, y: 191, r: 236, g: 226, b: 190 },
  { x: 442, y: 197, r: 238, g: 229, b: 195 },
  { x: 436, y: 204, r: 252, g: 237, b: 237 },
  { x: 427, y: 195, r: 255, g: 238, b: 238 },
  { x: 434, y: 198, r: 239, g: 227, b: 192 },
  { x: 437, y: 196, r: 239, g: 227, b: 190 },
];

var pagePlayMedia = [
  { x: 433, y: 180, r: 219, g: 179, b: 93 },
  { x: 444, y: 184, r: 191, g: 143, b: 83 },
  { x: 435, y: 192, r: 237, g: 227, b: 193 },
  { x: 445, y: 200, r: 202, g: 139, b: 86 },
  { x: 423, y: 191, r: 213, g: 176, b: 84 },
  { x: 435, y: 201, r: 250, g: 236, b: 221 },
];

var pageTakePicture = [
  { x: 477, y: 133, r: 242, g: 133, b: 168 },
  { x: 431, y: 142, r: 235, g: 239, b: 247 },
  { x: 414, y: 201, r: 147, g: 197, b: 238 },
  { x: 447, y: 202, r: 117, g: 147, b: 223 },
  { x: 435, y: 176, r: 235, g: 239, b: 247 },
];

var pageWearSomething = [
  { x: 452, y: 202, r: 63, g: 147, b: 207 },
  { x: 455, y: 202, r: 125, g: 153, b: 227 },
  { x: 417, y: 200, r: 153, g: 201, b: 239 },
  { x: 478, y: 131, r: 234, g: 122, b: 154 },
];

var pageTalking = [
  { x: 576, y: 15, r: 117, g: 94, b: 113 },
  { x: 575, y: 18, r: 255, g: 255, b: 255 },
];

var pageTaskTakeTrain = [
  { x: 427, y: 182, r: 212, g: 179, b: 84 },
  { x: 447, y: 183, r: 215, g: 177, b: 94 },
  { x: 433, y: 195, r: 237, g: 228, b: 195 },
  { x: 425, y: 205, r: 219, g: 163, b: 84 },
  { x: 444, y: 205, r: 230, g: 195, b: 154 },
];

var pageTaskSayBoodbye = [
  { x: 424, y: 125, r: 228, g: 208, b: 111 },
  { x: 444, y: 126, r: 189, g: 153, b: 98 },
  { x: 434, y: 131, r: 239, g: 227, b: 190 },
  { x: 421, y: 142, r: 180, g: 141, b: 73 },
  { x: 442, y: 142, r: 207, g: 154, b: 104 },
];

var pageTaskQuestion = [
  { x: 406, y: 289, r: 145, g: 203, b: 250 },
  { x: 138, y: 267, r: 235, g: 229, b: 215 },
  { x: 500, y: 272, r: 235, g: 229, b: 215 },
  { x: 220, y: 297, r: 222, g: 129, b: 154 },
  { x: 419, y: 299, r: 138, g: 165, b: 244 },
];

var pageTaskReadBook = [
  { x: 530, y: 51, r: 255, g: 255, b: 255 },
  { x: 226, y: 58, r: 235, g: 233, b: 223 },
  { x: 411, y: 62, r: 235, g: 232, b: 223 },
  { x: 228, y: 256, r: 235, g: 233, b: 223 },
  { x: 423, y: 256, r: 235, g: 230, b: 219 },
  { x: 542, y: 57, r: 255, g: 189, b: 196 },
];

var pageTaskFish = [
  { x: 389, y: 137, r: 212, g: 188, b: 109 },
  { x: 406, y: 137, r: 168, g: 151, b: 84 },
  { x: 390, y: 143, r: 252, g: 245, b: 244 },
  { x: 396, y: 149, r: 250, g: 243, b: 234 },
  { x: 396, y: 142, r: 244, g: 240, b: 218 },
  { x: 406, y: 145, r: 194, g: 152, b: 94 },
];

var pageTaskEnforceWeapon = [
  { x: 568, y: 216, r: 162, g: 216, b: 255 },
  { x: 588, y: 216, r: 170, g: 219, b: 255 },
  { x: 592, y: 250, r: 166, g: 215, b: 254 },
  { x: 334, y: 281, r: 234, g: 234, b: 234 },
  { x: 177, y: 344, r: 226, g: 217, b: 234 },
  { x: 506, y: 339, r: 227, g: 220, b: 238 },
  { x: 535, y: 221, r: 162, g: 203, b: 255 },
  { x: 535, y: 216, r: 162, g: 217, b: 255 },
];

var pageTask100 = [
  { x: 354, y: 225, r: 125, g: 153, b: 227 },
  { x: 227, y: 115, r: 229, g: 220, b: 196 },
  { x: 436, y: 118, r: 245, g: 237, b: 212 },
  { x: 608, y: 28, r: 164, g: 163, b: 182 },
  { x: 560, y: 169, r: 138, g: 138, b: 146 },
  { x: 78, y: 178, r: 138, g: 138, b: 146 },
];
var pageTask101 = [
  { x: 452, y: 203, r: 125, g: 153, b: 227 },
  { x: 461, y: 132, r: 239, g: 115, b: 148 },
  { x: 469, y: 128, r: 220, g: 112, b: 135 },
  { x: 475, y: 134, r: 245, g: 152, b: 178 },
  { x: 466, y: 136, r: 249, g: 249, b: 255 },
  { x: 413, y: 203, r: 146, g: 196, b: 237 },
];
var pageTask102 = [
  { x: 319, y: 326, r: 144, g: 180, b: 113 },
  { x: 320, y: 129, r: 73, g: 84, b: 140 },
  { x: 525, y: 30, r: 253, g: 253, b: 253 },
  { x: 26, y: 28, r: 165, g: 168, b: 182 },
  { x: 591, y: 68, r: 60, g: 66, b: 117 },
  { x: 20, y: 242, r: 73, g: 101, b: 187 },
];
var pageTaskCannotDo = [
  { x: 397, y: 232, r: 125, g: 153, b: 227 },
  { x: 317, y: 231, r: 231, g: 230, b: 235 },
  { x: 287, y: 231, r: 224, g: 157, b: 85 },
  { x: 339, y: 104, r: 121, g: 110, b: 113 },
  { x: 325, y: 140, r: 231, g: 231, b: 235 },
  { x: 439, y: 114, r: 249, g: 249, b: 255 },
];
var pageMain = [
  { x: 15, y: 121, r: 245, g: 212, b: 181 },
  { x: 68, y: 25, r: 210, g: 210, b: 227 },
  { x: 40, y: 352, r: 211, g: 213, b: 223 },
  { x: 617, y: 352, r: 211, g: 213, b: 223 },
  { x: 604, y: 13, r: 227, g: 227, b: 227 },
];

var pageFinish = [
  { x: 612, y: 27, r: 166, g: 169, b: 182 },
  { x: 319, y: 13, r: 141, g: 124, b: 101 },
  { x: 133, y: 336, r: 137, g: 137, b: 145 },
  { x: 208, y: 338, r: 137, g: 137, b: 145 },
  { x: 436, y: 339, r: 138, g: 138, b: 146 },
  { x: 524, y: 340, r: 138, g: 138, b: 146 },
  { x: 587, y: 48, r: 138, g: 138, b: 146 },
];

var pageFinalStopScript = [
  { x: 520, y: 22, r: 93, g: 143, b: 231 },
  { x: 483, y: 23, r: 227, g: 203, b: 211 },
  { x: 445, y: 24, r: 255, g: 247, b: 222 },
  { x: 404, y: 23, r: 225, g: 208, b: 174 },
  { x: 368, y: 23, r: 250, g: 234, b: 184 },
  { x: 519, y: 56, r: 238, g: 154, b: 157 },
  { x: 485, y: 58, r: 255, g: 227, b: 159 },
];

var pageDialogNeedClick = [
  { x: 486, y: 339, r: 140, g: 167, b: 114 },
  { x: 219, y: 282, r: 233, g: 233, b: 233 },
  { x: 503, y: 284, r: 233, g: 233, b: 233 },
  { x: 232, y: 337, r: 227, g: 221, b: 235 },
  { x: 484, y: 339, r: 221, g: 212, b: 228 },
  { x: 488, y: 337, r: 169, g: 233, b: 108 },
];

var pageHasTransferTask = [
  { x: 37, y: 141, r: 78, g: 128, b: 213 },
  { x: 40, y: 141, r: 72, g: 115, b: 188 },
  { x: 45, y: 142, r: 57, g: 83, b: 128 },
  { x: 47, y: 142, r: 59, g: 84, b: 130 },
  { x: 66, y: 142, r: 149, g: 148, b: 149 },
  { x: 13, y: 123, r: 238, g: 221, b: 187 },
];
var pageHasTransferTask2 = [
  { x: 37, y: 142, r: 80, g: 115, b: 182 },
  { x: 39, y: 142, r: 77, g: 92, b: 135 },
  { x: 46, y: 142, r: 84, g: 108, b: 166 },
  { x: 48, y: 142, r: 88, g: 121, b: 186 },
  { x: 66, y: 142, r: 183, g: 177, b: 179 },
  { x: 13, y: 122, r: 254, g: 230, b: 205 },
];

var pageNeedWare = [
  { x: 591, y: 312, r: 242, g: 223, b: 215 },
  { x: 582, y: 300, r: 233, g: 221, b: 215 },
  { x: 599, y: 295, r: 184, g: 173, b: 179 },
  { x: 616, y: 259, r: 255, g: 255, b: 255 },
  { x: 493, y: 319, r: 163, g: 187, b: 196 },
  { x: 506, y: 270, r: 201, g: 215, b: 153 },
  { x: 549, y: 225, r: 102, g: 119, b: 153 },
  { x: 566, y: 296, r: 235, g: 206, b: 202 },
  { x: 583, y: 295, r: 242, g: 229, b: 222 },
  { x: 559, y: 298, r: 191, g: 209, b: 178 },
];

var pageRunning = [
  { x: 304, y: 119, r: 238, g: 249, b: 249 },
  { x: 303, y: 120, r: 237, g: 249, b: 249 },
  { x: 299, y: 121, r: 231, g: 252, b: 254 },
  { x: 296, y: 118, r: 191, g: 242, b: 246 },
  { x: 296, y: 113, r: 197, g: 240, b: 242 },
  { x: 300, y: 120, r: 232, g: 254, b: 255 },
  { x: 300, y: 116, r: 237, g: 255, b: 255 },
  { x: 300, y: 120, r: 227, g: 253, b: 254 },
  { x: 305, y: 118, r: 193, g: 240, b: 236 },
  { x: 302, y: 120, r: 228, g: 253, b: 255 },
];

var pageMessage = [
  { x: 303, y: 180, r: 94, g: 143, b: 226 },
  { x: 233, y: 20, r: 245, g: 245, b: 246 },
  { x: 28, y: 19, r: 205, g: 203, b: 207 },
  { x: 60, y: 344, r: 255, g: 255, b: 255 },
  { x: 193, y: 344, r: 255, g: 255, b: 255 },
  { x: 284, y: 342, r: 131, g: 156, b: 223 },
];
var pageWaitForGirlGod = [
  { x: 522, y: 27, r: 175, g: 161, b: 173 },
  { x: 527, y: 30, r: 236, g: 231, b: 236 },
  { x: 571, y: 17, r: 41, g: 43, b: 73 },
  { x: 568, y: 29, r: 227, g: 226, b: 234 },
  { x: 27, y: 28, r: 166, g: 169, b: 182 },
  { x: 36, y: 36, r: 223, g: 223, b: 239 },
];

var pageNeedWereWeapon1 = [
  { x: 417, y: 201, r: 147, g: 197, b: 238 },
  { x: 457, y: 201, r: 125, g: 153, b: 227 },
  { x: 450, y: 144, r: 235, g: 239, b: 247 },
  { x: 424, y: 169, r: 235, g: 239, b: 247 },
];
var pageNeedFish = [
  { x: 435, y: 326, r: 241, g: 224, b: 209 },
  { x: 444, y: 329, r: 213, g: 179, b: 179 },
  { x: 436, y: 338, r: 247, g: 239, b: 231 },
  { x: 535, y: 247, r: 240, g: 231, b: 223 },
  { x: 548, y: 255, r: 250, g: 245, b: 250 },
  { x: 526, y: 89, r: 253, g: 253, b: 253 },
];

var pageDied = [
  { x: 568, y: 320, r: 125, g: 153, b: 226 },
  { x: 463, y: 227, r: 231, g: 204, b: 184 },
  { x: 626, y: 227, r: 235, g: 213, b: 195 },
  { x: 543, y: 274, r: 233, g: 230, b: 237 },
  { x: 511, y: 320, r: 156, g: 201, b: 241 },
  { x: 552, y: 195, r: 230, g: 206, b: 191 },
];
var pageLeaveChair = [
  { x: 600, y: 221, r: 236, g: 227, b: 191 },
  { x: 601, y: 214, r: 238, g: 229, b: 194 },
  { x: 513, y: 245, r: 235, g: 227, b: 189 },
  { x: 494, y: 315, r: 236, g: 227, b: 194 },
  { x: 488, y: 323, r: 237, g: 229, b: 196 },
];
var pageLevelUp = [
  { x: 53, y: 5, r: 249, g: 167, b: 51 },
  { x: 54, y: 6, r: 254, g: 145, b: 16 },
  { x: 54, y: 8, r: 252, g: 167, b: 48 },
  { x: 54, y: 11, r: 255, g: 135, b: 8 },
  { x: 53, y: 13, r: 241, g: 150, b: 33 },
];

var tmpMemory = {
  taskMenuImg: undefined,
};

function isSameColor(c1, c2, diff) {
  if (diff === undefined) {
    diff = 35;
  }
  // console.log(JSON.stringify(c1), JSON.stringify(c2), diff);
  if (
    Math.abs(c1.r - c2.r) < diff &&
    Math.abs(c1.g - c2.g) < diff &&
    Math.abs(c1.b - c2.b) < diff
  ) {
    return true;
  }
  return false;
}

function checkIsPage(page, img) {
  var release = false;
  if (img === undefined) {
    img = getScreenshot();
    release = true;
  }
  var whSize = getImageSize(img);
  if (whSize.width === 360) {
    throw new Error("ROBroken");
  }
  var isPage = true;
  for (var i in page) {
    var cbtn = page[i];
    var color = getImageColor(img, cbtn.x, cbtn.y);
    if (!isSameColor(cbtn, color)) {
      isPage = false;
      break;
    }
  }
  if (release) {
    releaseImage(img);
  }
  return isPage;
}

function goMainGamePage() {
  for (var i = 0; i < 2; i++) {
    if (checkIsPage(pageMain)) {
      // console.log('page: main');
      return true;
    }
    console.log("NotMainPage Back", i, "/", 1);
    if (checkIsPage(pageQuitDialog)) {
      keycode("BACK", gConfig.sleep);
      // console.log('page: main');
      return true;
    } else {
      keycode("BACK", gConfig.sleep);
    }
    sleep(1000);
  }
  return false;
}

function handleTaskDialgoComfirmPage() {
  var act = false;
  var img = getScreenshot();
  if (checkIsPage(pageDialog, img)) {
    for (var i = 0; i < cbtnTaskDialogConfirms.length; i++) {
      var comfirm = cbtnTaskDialogConfirms[i];
      var color = getImageColor(img, comfirm.x, comfirm.y);
      if (isSameColor(comfirm, color)) {
        console.log("handleTaskDialgoComfirmPage");
        tap(comfirm.x, comfirm.y, gConfig.sleep);
        tap(comfirm.x, comfirm.y, gConfig.sleep);
        sleep(gConfig.sleepAnimate);
        tap(cbtnDialogSkip.x, cbtnDialogSkip.y, gConfig.sleep);
        act = true;
      }
    }
  }
  releaseImage(img);
  return act;
}
function handelCheckSomething(img) {
  if (checkIsPage(pageCheckSomething9, img)) {
    console.log("handelCheckSomething9");
    tap(pageCheckSomething9[0].x, pageCheckSomething9[0].y, gConfig.sleep);
    sleep(3000);
    return true;
  }
  if (checkIsPage(pageCheckSomething10, img)) {
    console.log("handelCheckSomething10");
    tap(pageCheckSomething10[0].x, pageCheckSomething10[0].y, gConfig.sleep);
    sleep(3000);
    return true;
  }
  if (checkIsPage(pageCheckSomething11, img)) {
    console.log("handelCheckSomething11");
    tap(pageCheckSomething11[0].x, pageCheckSomething11[0].y, gConfig.sleep);
    sleep(3000);
    return true;
  }
  if (checkIsPage(pageCheckSomething12, img)) {
    console.log("handelCheckSomething12");
    tap(pageCheckSomething12[0].x, pageCheckSomething12[0].y, gConfig.sleep);
    sleep(3000);
    return true;
  }
  return false;
}
function handleTakePicture(img) {
  if (checkIsPage(pageTakePicture, img)) {
    console.log("handleTakePicture");
    tap(cbtnTakePicture.x, cbtnTakePicture.y, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(cbtnAttack.x, cbtnAttack.y, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    keycode("BACK", gConfig.sleep);
    return true;
  }
  return false;
}
function handleTaskDialogGiveSomething(img) {
  if (checkIsPage(pageTaskDialogGiveSomething, img)) {
    console.log("handleTaskDialogGiveSomething");
    tap(
      pageTaskDialogGiveSomething[0].x,
      pageTaskDialogGiveSomething[0].y,
      gConfig.sleep
    );
    sleep(gConfig.sleepAnimate * 2);
    tap(540, 307, gConfig.sleep);
    return true;
  }
  return false;
}
function handleTaskDialogMakeSomething(img) {
  if (checkIsPage(pageTaskDialogMakeSomething, img)) {
    console.log("handleTaskDialogMakeSomething");
    tap(
      pageTaskDialogMakeSomething[0].x,
      pageTaskDialogMakeSomething[0].y,
      gConfig.sleep
    );
    sleep(gConfig.sleepAnimate * 3);
    tap(516, 316, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 3);
    tap(395, 231, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 3);
    tap(395, 308, gConfig.sleep);
    return true;
  }
  return false;
}
function handleTaskQuestion(img) {
  if (checkIsPage(pageTaskQuestion, img)) {
    console.log("handleTaskQuestion");
    sleep(gConfig.sleepAnimate);
    tap(408, 289, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    if (Math.floor(Math.random() * 2) === 0) {
      console.log("handleTaskQuestion X");
      tap(226, 289, gConfig.sleep);
    } else {
      console.log("handleTaskQuestion O");
      tap(408, 289, gConfig.sleep);
    }
    sleep(gConfig.sleepAnimate * 2);
    tap(408, 289, gConfig.sleep);
    return true;
  }
  return false;
}
function handleTaskTransferLicense(img) {
  if (checkIsPage(pageTaskTransferLicense, img)) {
    console.log("handleTaskTransferLicense");
    clickEmpty();
    return true;
  }
  return false;
}
function handleTaskTransferCheck(img) {
  if (checkIsPage(pageMain)) {
    return;
  }
  if (checkIsPage(pageTaskTransferCheck, img)) {
    console.log("handleTaskTransferCheck");
    sleep(gConfig.sleepAnimate * 4);
    tap(459, 275, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(459, 275, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 4);
    tap(594, 310, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(594, 310, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 4);
    tap(375, 232, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(375, 232, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 4);
    tap(319, 325, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(319, 325, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 4);
    tap(319, 325, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(319, 325, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 4);
    // tap(pageTaskTransferCheck[0].x, pageTaskTransferCheck[0].y, gConfig.sleep);
    handleAttackTest();
    return true;
  }
  return false;
}
function handleAttackTest() {
  console.log("handleAttackTest start");
  tap(613, 258, gConfig.sleep);
  var oriImg = getScreenshot();
  // saveImage(oriImg, "/sdcard/aa.jpg");
  var now = Date.now();
  for (var i = 0; i < 100; i++) {
    tap(597, 215, gConfig.sleep);
    tap(547, 230, gConfig.sleep);
    tap(508, 270, gConfig.sleep);
    tap(491, 326, gConfig.sleep);
    sleep(1000);
    var img = getScreenshot();
    var score = getIdentityScore(oriImg, img);
    console.log("attackTest", score);
    releaseImage(img);
    if (score !== 0 && score < 0.9 && Date.now() - now > 45 * 1000) {
      break;
    }
    if (checkIsPage(pageTaskTransferCheck)) {
      break;
    }
  }
  releaseImage(oriImg);
  console.log("handleAttackTest done");
  sleep(10000);
  tap(459, 275, gConfig.sleep);
  tap(459, 275, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 3);
  tap(594, 310, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 2);
  tap(368, 232, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 2);
}
function handleTaskFish(img) {
  if (checkIsPage(pageTaskFish, img)) {
    console.log("handleTaskFish");
    tap(pageTaskFish[0].x, pageTaskFish[0].y, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    fish();
    return true;
  }
  return false;
}
function handleTaskDialogMakeSomething6(img) {
  // alien testing
  if (checkIsPage(pageTaskDialogMakeSomething6, img)) {
    console.log("handleTaskDialogMakeSomething6");
    tap(
      pageTaskDialogMakeSomething6[0].x,
      pageTaskDialogMakeSomething6[0].y,
      gConfig.sleep
    );
    for (var i = 0; i < 3; i++) {
      sleep(gConfig.sleepAnimate);
      tap(492, 337, gConfig.sleep);
    }

    sleep(gConfig.sleepAnimate);
    tap(
      pageTaskDialogMakeSomething6[0].x,
      pageTaskDialogMakeSomething6[0].y,
      gConfig.sleep
    );
    for (var i = 0; i < 8; i++) {
      sleep(gConfig.sleepAnimate);
      tap(492, 337, gConfig.sleep);
    }
    return true;
  }
  return false;
}
function handleTask102(img) {
  if (checkIsPage(pageTask102, img)) {
    console.log("handleTask102");
    tap(pageTask102[0].x, pageTask102[0].y, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tapDown(317, 204, gConfig.sleep);
    sleep(4000);
    tapUp(317, 204, gConfig.sleep);
    return true;
  }
  return false;
}
function handleWaitForGirlGod(img) {
  if (checkIsPage(pageWaitForGirlGod, img)) {
    console.log("handleWaitForGirlGod");
    sleep(8000);
    return true;
  }
  return false;
}
function handleFinalTask(img) {
  if (checkIsPage(pageFinish, img)) {
    console.log("handleFinalTask");
    if (!goMainGamePage()) {
      return false;
    }
    sleep(gConfig.sleepAnimate * 2);
    tap(520, 21, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(406, 21, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);

    tap(61, 67, gConfig.sleep);
    sleep(gConfig.sleepAnimate);

    tap(230, 96, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);

    tap(335, 111, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);

    tap(269, 153, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);

    tap(321, 182, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(547, 318, gConfig.sleep);
    sleep(gConfig.sleepAnimate);

    tap(61, 101, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(177, 181, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(534, 115, gConfig.sleep);
    sleep(gConfig.sleepAnimate);

    goMainGamePage();
    return true;
  }
  return false;
}
function handleStopScript(img) {
  if (checkIsPage(pageFinalStopScript, img)) {
    if (!goMainGamePage()) {
      return false;
    }
    sleep(gConfig.sleepAnimate * 2);
    goLine1st();
    sleep(gConfig.sleepAnimate * 2);
    if (!goMainGamePage()) {
      return false;
    }
    sleep(gConfig.sleepAnimate * 2);
    // console.log("handleStopScript, moving");
    console.log("handleStopScript");
    // tap(585, 73, gConfig.sleep);
    // sleep(gConfig.sleepAnimate * 3);
    // tap(595, 203, gConfig.sleep);
    // sleep(30 * 1000);
    // if (!buyAndSell()) {
    //   return false;
    // }
    if (!goMainGamePage()) {
      return false;
    }
    // logout();
    gConfig.isMainTask = false;

    return true;
  }
  return false;
}
var shops = [
  { x: 317, y: 136, r: 221, g: 222, b: 228 },
  { x: 351, y: 163, r: 221, g: 222, b: 228 },
  { x: 406, y: 196, r: 221, g: 222, b: 228 },
  { x: 430, y: 129, r: 221, g: 222, b: 228 },
  { x: 327, y: 98, r: 221, g: 222, b: 228 },
  { x: 211, y: 133, r: 221, g: 222, b: 228 },
];
var pageShop = [
  { x: 233, y: 47, r: 117, g: 171, b: 219 },
  { x: 397, y: 49, r: 117, g: 172, b: 219 },
  { x: 216, y: 305, r: 224, g: 224, b: 224 },
  { x: 443, y: 313, r: 224, g: 224, b: 224 },
  { x: 493, y: 44, r: 255, g: 255, b: 255 },
];
function buyAndSell() {
  console.log("Find Shop");
  while (true) {
    var img = getScreenshot();
    for (var i = 0; i < shops.length; i++) {
      var shop = shops[i];
      var color = getImageColor(img, shop.x, shop.y);
      if (isSameColor(color, shop));
      {
        tap(shop.x, shop.y, 100);
        tap(shop.x, shop.y, 100);
        break;
      }
    }
    releaseImage(img);
    sleep(gConfig.sleepAnimate * 3);
    if (!checkIsPage(pageShop)) {
      console.log("NotShopPage");
      sleep(5000);
      continue;
    }
    console.log("ShopPage");
    for (var i = 0; i < 5; i++) {
      tap(230, 78, gConfig.sleep);
      sleep(gConfig.sleepAnimate * 3);

      tap(259, 121, gConfig.sleep); // first
      sleep(gConfig.sleepAnimate * 3);
      tap(384, 201, gConfig.sleep); // max
      sleep(gConfig.sleepAnimate * 1);
      tap(339, 300, gConfig.sleep); // buy
      sleep(gConfig.sleepAnimate * 3);

      if (!checkIsPage(pageShop)) {
        console.log("NotShopPage");
        sleep(5000);
        return false;
      }

      tap(325, 78, gConfig.sleep);
      sleep(gConfig.sleepAnimate * 3);

      tap(259, 121, gConfig.sleep); // first
      sleep(gConfig.sleepAnimate * 3);
      tap(384, 201, gConfig.sleep); // max
      sleep(gConfig.sleepAnimate * 1);
      tap(339, 300, gConfig.sleep); // buy
      sleep(gConfig.sleepAnimate * 3);

      if (!checkIsPage(pageShop)) {
        console.log("NotShopPage");
        sleep(5000);
        return false;
      }
    }
    break;
  }
  return true;
}
function handleNeedWare(img) {
  if (checkIsPage(pageNeedWare, img)) {
    console.log("handleNeedWare");
    ware();
  }
  return false;
}
function handleTaskEnforceWeapon(img) {
  if (checkIsPage(pageTaskEnforceWeapon, img)) {
    console.log("handleTaskEnforceWeapon");
    tap(pageTaskEnforceWeapon[0].x, pageTaskEnforceWeapon[0].y, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 3);
    tap(501, 308, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(593, 23, gConfig.sleep);
    return true;
  }
  return false;
}
function handleNeedWereWeapon1(img) {
  if (checkIsPage(pageNeedWereWeapon1, img)) {
    console.log("handleNeedWereWeapon1");
    ware();
    return true;
  }
  return false;
}
function handleNeedFish(img) {
  if (checkIsPage(pageNeedFish, img)) {
    console.log("handleNeedFish");
    fish();
    sleep(gConfig.sleepAnimate);
    tap(60, 126, gConfig.sleep); // task
    return true;
  }
  return false;
}
function handleDialogNeetClick(img) {
  if (checkIsPage(pageDialogNeedClick, img)) {
    console.log("handleDialogNeetClick");
    tap(pageDialogNeedClick[0].x, pageDialogNeedClick[0].y, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(cbtnDialogSkip.x, cbtnDialogSkip.y, gConfig.sleep);
    return true;
  }
  return false;
}
function handleLevelUp(img) {
  if (checkIsPage(pageLevelUp, img)) {
    console.log("handleLevelUp");
    return autoAddBodyPoints();
  }
  return false;
}

function goLine1st() {
  tap(625, 11, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 2);
  tap(282, 114, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 2);
}
function logout() {
  // config.finish = true;
  tap(618, 132, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 4);
  tap(511, 246, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 3);
  tap(468, 297, gConfig.sleep);
  sleep(gConfig.sleepAnimate * 3);
  tap(376, 230, gConfig.sleep);
  sleep(20 * 1000);
  throw new Error("RunNext");
}

var handleSkipPage = makeSimpleHandler(
  "handleSkipPage",
  pageTalking,
  cbtnDialogSkip.x,
  cbtnDialogSkip.y
);
var handlePlayMedia = makeSimpleHandler(
  "handlePlayMedia",
  pagePlayMedia,
  pagePlayMedia[0].x,
  pagePlayMedia[0].y
);
var handleTaskAddFriend = makeSimpleHandler(
  "pageTaskAddFriend",
  pageTaskAddFriend,
  cbtnTaskAddFriend.x,
  cbtnTaskAddFriend.y
);
var handleTaskSelectBrew = makeSimpleHandler(
  "handleTaskSelectBrew",
  pageTaskSelectBrew,
  420,
  229
);
var handleTaskSayBoodbye = makeSimpleHandler(
  "handleTaskSayBoodbye",
  pageTaskSayBoodbye,
  pageTaskSayBoodbye[0].x,
  pageTaskSayBoodbye[0].y
);
var handleTaskTrain = makeSimpleHandler(
  "handleTaskTrain",
  pageTaskTakeTrain,
  pageTaskTakeTrain[0].x,
  pageTaskTakeTrain[0].y
);
var handleWearSomething = makeSimpleHandler(
  "handleWearSomething",
  pageWearSomething,
  pageWearSomething[0].x,
  pageWearSomething[0].y
);
var handleTaskAddHP = makeSimpleHandler(
  "handleTaskAddHP",
  pageTaskAddHP,
  pageTaskAddHP[0].x,
  pageTaskAddHP[0].y
);
var handleTaskPretendDead = makeSimpleHandler(
  "handleTaskPretendDead",
  pageTaskPretendDead,
  pageTaskPretendDead[0].x,
  pageTaskPretendDead[0].y
);
var handleTaskPretendDead2 = makeSimpleHandler(
  "handleTaskPretendDead2",
  pageTaskPretendDead2,
  pageTaskPretendDead2[0].x,
  pageTaskPretendDead2[0].y
);
var handleTaskReadBook = makeSimpleHandler(
  "handleTaskReadBook",
  pageTaskReadBook,
  pageTaskReadBook[0].x,
  pageTaskReadBook[0].y
);
var handleMessage = makeSimpleHandler(
  "handleMessage",
  pageMessage,
  pageMessage[0].x,
  pageMessage[0].y
);

var handleTaskDialogMakeSomething2 = makeSimpleHandler(
  "handleTaskDialogMakeSomething2",
  pageTaskDialogMakeSomething2,
  pageTaskDialogMakeSomething2[0].x,
  pageTaskDialogMakeSomething2[0].y
);
var handleTaskDialogMakeSomething3 = makeSimpleHandler(
  "handleTaskDialogMakeSomething3",
  pageTaskDialogMakeSomething3,
  pageTaskDialogMakeSomething3[0].x,
  pageTaskDialogMakeSomething3[0].y
);
var handleTaskDialogMakeSomething4 = makeSimpleHandler(
  "handleTaskDialogMakeSomething4",
  pageTaskDialogMakeSomething4,
  pageTaskDialogMakeSomething4[0].x,
  pageTaskDialogMakeSomething4[0].y
);
var handleTaskDialogMakeSomething5 = makeSimpleHandler(
  "handleTaskDialogMakeSomething5",
  pageTaskDialogMakeSomething5,
  pageTaskDialogMakeSomething5[0].x,
  pageTaskDialogMakeSomething5[0].y
);
var handleTaskEnforceWeapon = makeSimpleHandler(
  "handleTaskEnforceWeapon",
  pageTaskEnforceWeapon,
  pageTaskEnforceWeapon[0].x,
  pageTaskEnforceWeapon[0].y
);
var handlePageTask100 = makeSimpleHandler(
  "handlePageTask100",
  pageTask100,
  pageTask100[0].x,
  pageTask100[0].y
);
var handlePageTask101 = makeSimpleHandler(
  "handlePageTask101",
  pageTask101,
  pageTask101[0].x,
  pageTask101[0].y
);
// var handleDialogNeetClick = makeSimpleHandler('handleDialogNeetClick', pageDialogNeedClick, pageDialogNeedClick[0].x, pageDialogNeedClick[0].y);
var handleTaskMakeEnforceWeapon = makeSimpleHandler(
  "handleTaskMakeEnforceWeapon",
  pageMakeEnforceItem,
  pageMakeEnforceItem[0].x,
  pageMakeEnforceItem[0].y
);
var handleDied = makeSimpleHandler(
  "handleDied",
  pageDied,
  pageDied[0].x,
  pageDied[0].y
);
var handleLeaveChair = makeSimpleHandler(
  "handleLeaveChair",
  pageLeaveChair,
  pageLeaveChair[0].x,
  pageLeaveChair[0].y
);
var handleNews = makeSimpleHandler(
  "handleNews",
  pageNews,
  pageNews[0].x,
  pageNews[0].y
);

// create role
var pageCreatingRole = [
  { x: 26, y: 29, r: 165, g: 168, b: 182 },
  { x: 485, y: 35, r: 98, g: 166, b: 243 },
  { x: 594, y: 33, r: 107, g: 154, b: 245 },
  { x: 546, y: 63, r: 227, g: 233, b: 239 },
  { x: 541, y: 199, r: 226, g: 233, b: 240 },
  { x: 506, y: 321, r: 165, g: 206, b: 240 },
  { x: 572, y: 320, r: 127, g: 153, b: 224 },
  { x: 259, y: 320, r: 194, g: 78, b: 78 },
];

var pageChoseRoles = [
  { x: 19, y: 22, r: 235, g: 229, b: 227 },
  { x: 35, y: 22, r: 231, g: 231, b: 239 },
  { x: 27, y: 27, r: 162, g: 165, b: 181 },
  { x: 25, y: 325, r: 251, g: 155, b: 155 },
  { x: 38, y: 320, r: 255, g: 219, b: 219 },
  { x: 39, y: 334, r: 255, g: 221, b: 221 },
];

function handleROInit(img) {
  if (checkIsPage(pageInit, img)) {
    console.log(
      "handleROInit",
      "region",
      gConfig.region,
      "server",
      gConfig.server
    );
    // Run over all servers
    for (var i = 0; i < 10; i++) {
      sleep(gConfig.sleepAnimate * 2);
      if (!checkIsPage(pageInitDone)) {
        continue;
      }
      tap(338, 256, gConfig.sleep); // select server
      sleep(gConfig.sleepAnimate * 3);
      findEmptyServer();
      break;
    }
  }
}
function findEmptyServer() {
  console.log("findEmptyServer", gConfig.region, gConfig.server);
  for (var r = gConfig.region; r < regions.length; r++) {
    var region = regions[r];
    tap(region.x, region.y, gConfig.sleep);
    tap(region.x, region.y, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    for (var s = gConfig.server; s < servers.length; s++) {
      var server = servers[s];
      gConfig.server++;
      var img = getScreenshot();
      var c = getImageColor(img, server.x, server.y);
      var ok = isSameColor(server, c, 10);
      releaseImage(img);
      if (ok) {
        tap(server.x, server.y, gConfig.sleep);
        tap(server.x, server.y, gConfig.sleep);
        sleep(gConfig.sleepAnimate * 2);
        sleep(gConfig.sleepAnimate * 2);
        tap(325, 315, gConfig.sleep); // go in server
        tap(325, 315, gConfig.sleep); // go in server
        console.log("goto server sleep 16 secs", r, s);
        sleep(16000);
        handleChoseRoles();
        return true;
      }
    }
    gConfig.region++;
    gConfig.server = 0;
  }
  return false;
}
function handleCreatingRole(img) {
  if (checkIsPage(pageCreatingRole, img)) {
    console.log("handleCreatingRole");
    for (var i = 0; i < 12; i++) {
      tap(261, 320, gConfig.sleep);
      sleep(gConfig.sleepAnimate * 2);
      tap(362, 322, gConfig.sleep);
      sleep(gConfig.sleepAnimate * 2);
      tap(362, 322, gConfig.sleep);
      sleep(gConfig.sleepAnimate * 2);
      // type some random words
      typing("X" + Math.ceil(Math.random() * 1000), 1000);
      tap(591, 323, gConfig.sleep);

      sleep(gConfig.sleepAnimate * 2);
      tap(550, 327, gConfig.sleep);
      sleep(gConfig.sleepAnimate * 2);
      tap(550, 327, gConfig.sleep);
      sleep(2 * 1000);
      if (checkIsPage(pageMain)) {
        break;
      }
    }
    return true;
  }
  return false;
}
function handleChoseRoles() {
  if (checkIsPage(pageChoseRoles)) {
    console.log("handleChoseRoles");
    var img = getScreenshot();
    for (var i = 0; i < 3; i++) {
      var c = getImageColor(img, okRoles[i].x, okRoles[i].y);
      if (!isSameColor(okRoles[i], c)) {
        tap(okRoles[i].x, okRoles[i].y, gConfig.sleep);
        sleep(gConfig.sleepAnimate * 3);
        tap(320, 320, gConfig.sleep);
        tap(320, 320, gConfig.sleep);
        console.log("handleChoseRoles choice, sleep 20 secs", i);
        sleep(20000);
        releaseImage(img);
        handleCreatingRole();
        return true;
      }
    }
    releaseImage(img);
    tap(29, 29, gConfig.sleep);
    console.log("NoEmptyRoles back, sleep 6 secs");
    sleep(6000);
    return true;
  }
  return false;
}

function fish() {
  var img = getScreenshot();
  var c = getImageColor(img, 548, 240);
  releaseImage(img);
  var start = false;
  if (
    c.r > 100 &&
    c.r < 210 &&
    c.g > 110 &&
    c.g < 250 &&
    c.b > 110 &&
    c.b < 230
  ) {
    tap(548, 240, 50);
    tap(548, 240, 50);
    start = true;
  }
  if (!start) {
    console.log("can not finish", c.r, c.g, c.b);
    return;
  }
  sleep(500);

  for (var i = 0; i < 60; i++) {
    var img = getScreenshot();
    var c = getImageColor(img, 548, 240);
    releaseImage(img);
    // console.log(i, c.r, c.b, c.g);
    var done = false;
    if (
      c.r > 140 &&
      c.r < 180 &&
      c.g > 180 &&
      c.g < 220 &&
      c.b > 110 &&
      c.b < 140
    ) {
      tap(548, 240, 100);
      done = true;
      console.log("done");
    }
    sleep(200);
    if (done) {
      break;
    }
  }
}
function makeSimpleHandler(name, page, x, y) {
  return function (img) {
    if (checkIsPage(page, img)) {
      console.log(name);
      tap(x, y, gConfig.sleep);
      return true;
    }
    return false;
  };
}

function isStop() {
  var img1 = getScreenshot();
  sleep(500);
  var img2 = getScreenshot();
  var score = getIdentityScore(img1, img2);
  var isStop = false;
  if (score > 0.99) {
    isStop = true;
  } else {
    if (score > 0.96) {
      isStop = true;
    }
    if (isStop) {
      if (checkIsPage(pageRunning, img1) && checkIsPage(pageRunning, img2)) {
        isStop = false;
      }
    }
  }
  releaseImage(img1);
  releaseImage(img2);
  console.log("isStop", isStop, score);
  return isStop;
}

// idx: number
function doOneTask(idx) {
  console.log("doOneTask");
  if (cbtnTaskMenus[idx] === undefined) {
    throw new Error("TaskNoIdx");
  }
  if (!goMainGamePage()) {
    throw new Error("NotMainPage");
  }
  sleep(gConfig.sleepAnimate);
  clickOneTask();
}
function clickOneTask() {
  if (checkIsPage(pageHasTransferTask) || checkIsPage(pageHasTransferTask2)) {
    // TODO
    console.log("Transfer JOB Task");
    tap(80, 160, gConfig.sleep);
  } else {
    tap(80, 120, gConfig.sleep);
  }
}

function clickEmpty() {
  console.log("clickEmpty");
  for (var i = 0; i < 5; i++) {
    tap(cbtnDialogSkip.x, cbtnDialogSkip.y, gConfig.sleep);
    tap(cbtnAttackEmpty.x, cbtnAttackEmpty.y, gConfig.sleep);
    sleep(1000);
  }
}

function isAutoAttacking() {
  return checkIsPage(pageAutoAttacking);
}

function autoAddBodyPoints() {
  if (checkIsPage(pageMain)) {
    sleep(gConfig.sleepAnimate * 2);
    tap(34, 33, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(607, 188, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(425, 70, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(184, 284, gConfig.sleep);
    sleep(gConfig.sleepAnimate * 2);
    tap(558, 319, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    tap(585, 30, gConfig.sleep);
    sleep(gConfig.sleepAnimate);
    return true;
  }
  return false;
}

function handleInitThings() {
  var handleEvents = [
    handleNews,
    handleROInit,
    handleChoseRoles,
    handleCreatingRole,
  ];
  sleep(gConfig.sleepAnimate);
  var act = false;
  var img = getScreenshot();
  // check whether dialog popup
  for (var i = 0; i < handleEvents.length; i++) {
    var handler = handleEvents[i];
    var isAct = handler(img);
    if (isAct) {
      act = true;
      releaseImage(img);
      sleep(gConfig.sleepAnimate);
      img = getScreenshot();
    }
  }
  releaseImage(img);
  return act;
}

function handleMainTaskThings() {
  var handleEvents = [
    handleTaskDialogGiveSomething,
    handleTaskDialgoComfirmPage,
    handleWaitForGirlGod,
    handleSkipPage,
    handelCheckSomething,
    handleTakePicture,
    handlePlayMedia,
    handleTaskAddFriend,
    handleTaskPretendDead,
    handleTaskPretendDead2,
    handleTaskAddHP,
    handleTaskEnforceWeapon,
    handleTaskDialogMakeSomething5,
    handleTaskDialogMakeSomething4,
    handleTaskDialogMakeSomething3,
    handleTaskDialogMakeSomething2,
    handleTaskDialogMakeSomething,
    handleWearSomething,
    handleTaskTrain,
    handleTaskSayBoodbye,
    handleTaskQuestion,
    handleTaskTransferCheck,
    handleTaskSelectBrew,
    handleTaskTransferLicense,
    handleTaskReadBook,
    handleTaskFish,
    handlePageTask100,
    handlePageTask101,
    handleTaskDialogMakeSomething6,
    handleTask102,
    handleFinalTask,
    handleStopScript,
    handleNeedWare,
    handleDialogNeetClick,
    handleMessage,
    handleTaskMakeEnforceWeapon,
    handleNeedFish,
    handleNeedWereWeapon1,
    handleDied,
    handleLeaveChair,
    handleSkipPage,
    handleLevelUp,
  ];
  sleep(gConfig.sleepAnimate);
  var act = false;
  var img = getScreenshot();
  // check whether dialog popup
  for (var i = 0; i < handleEvents.length; i++) {
    handler = handleEvents[i];
    var isAct = handler(img);
    if (isAct) {
      act = true;
      releaseImage(img);
      sleep(gConfig.sleepAnimate);
      img = getScreenshot();
    }
  }
  releaseImage(img);
  return act;
}

function ware() {
  tap(570, 130, gConfig.sleep);
  sleep(gConfig.sleepAnimate);
  tap(436, 70, gConfig.sleep);
  sleep(gConfig.sleepAnimate);
  tap(390, 120, gConfig.sleep);
  sleep(gConfig.sleepAnimate);
  tap(404, 289, gConfig.sleep);
  sleep(gConfig.sleepAnimate);
  tap(515, 290, gConfig.sleep);
  keycode("BACK", gConfig.sleep);
}

function moveRandom() {
  console.log("move random");
  tapDown(104, 285, gConfig.sleep);
  sleep(gConfig.sleep);
  moveTo(163, 246, gConfig.sleep);
  sleep(gConfig.sleep);
  moveTo(247, 202, gConfig.sleep);
  sleep(gConfig.sleep);
  moveTo(367, 222, gConfig.sleep);
  sleep(gConfig.sleep);
  moveTo(374, 84, gConfig.sleep);
  sleep(gConfig.sleep);
  moveTo(130, 77, gConfig.sleep);
  sleep(gConfig.sleep);
  moveTo(61, 240, gConfig.sleep);
  sleep(gConfig.sleep);
  tapUp(104, 285, gConfig.sleep);
  sleep(gConfig.sleep);
}

function startMainTask(activeTimes) {
  var runMain = false;
  console.log("activeTimes :", activeTimes);
  if (checkIsPage(pageMain)) {
    runMain = true;
  } else if (checkIsPage(pageQuitDialog)) {
    keycode("BACK", gConfig.sleep);
  } else if (activeTimes % 17 === 0) {
    keycode("BACK", gConfig.sleep);
  } else if (activeTimes % 20 === 0) {
    var act = handleMainTaskThings();
    if (act) {
      runMain = true;
    }
  } else if (activeTimes % 40 === 0) {
    console.log("Error Stuck Too Long");
    execute("reboot -p");
  } else {
    var act = handleInitThings();
    if (act) {
      activeTimes = 1; // reset
    }
  }
  
  if (runMain) {
    console.log("Start Main Task Loop");
    mainTaskLoop();
    activeTimes = 1;
  }
  activeTimes++;
  sleep(3000);
  return;
}

function mainTaskLoop() {
  var run = 0;
  var taskIdx = 0;
  var now = Date.now();
  var stopStartTime = now;
  var runStartTime = now;
  while (gConfig.isMainTask) {
    var currentTime = Date.now();
    run++;
    if (!isStop()) {
      if (currentTime - runStartTime > 6000) {
        if (!checkIsPage(pageMain)) {
          console.log("Not MainPage. run > 6 sec click skip");
          for (var i = 0; i < 3; i++) {
            tap(cbtnDialogSkip.x, cbtnDialogSkip.y, gConfig.sleep);
          }
        }
      }
      sleep(1000);
      stopStartTime = currentTime;
    } else {
      runStartTime = currentTime;
      if (currentTime - stopStartTime > 90 * 1000) {
        // maybe task stuck
        tap(522, 92, gConfig.sleep);
        sleep(gConfig.sleepAnimate);
        tap(371, 230, gConfig.sleep);
        sleep(gConfig.sleepAnimate);
        stopStartTime = currentTime;
      } else if (
        currentTime - stopStartTime > 60 * 1000 &&
        currentTime - stopStartTime < 70 * 1000
      ) {
        // maybe ro bug, moving a little
        moveRandom();
      }
    }

    console.log(
      "Run Run TaskIdx",
      taskIdx,
      "run",
      run,
      "time(sec)",
      Math.ceil((Date.now() - now) / 1000),
      "stopTime",
      currentTime - stopStartTime,
      "runTime",
      currentTime - runStartTime
    );

    if (isAutoAttacking()) {
      console.log("attacking wait and stop");
      sleep(gConfig.sleepAttack);
      if (isAutoAttacking()) {
        tap(pageAutoAttacking[0].x, pageAutoAttacking[0].y, gConfig.sleep * 2);
        sleep(gConfig.sleepAnimate);
      }
    }

    var act = handleMainTaskThings();
    if (!gConfig.isMainTask)
    { 
      console.log("Exit Main Task");
      return;
    }
    console.log("do handleThings act", act);
    sleep(gConfig.sleepAnimate);

    if (act && checkIsPage(pageMain)) {
      console.log("DoQuickTask");
      sleep(gConfig.sleepAnimate);
      clickOneTask();
      sleep(1000);
      continue;
    }

    try {
      doOneTask(taskIdx);
      console.log("DoTask");
      if (checkIsPage(pageTaskCannotDo)) {
        throw new Error("CannotDoTask");
      }
    } catch (e) {
      console.log("DoTaskError", e.message);
      sleep(1000);
    }

    sleep(1000);
  }
}

function mainTaskManager(config) {
  gConfig = config;
  this.init();
}

mainTaskManager.prototype.init = function () {
  console.log("MainTaskManager init");
  this.mActiveTimes = 1;
};

mainTaskManager.prototype.autoMainTask = function () {
  if (gConfig.isMainTask)
  { 
    startMainTask(this.mActiveTimes);
  }
  console.log("gConfig.isMainTask", gConfig.isMainTask);
  return gConfig.isMainTask;
};

module.exports = mainTaskManager;


/***/ }),

/***/ 671:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function MiningManager(config) {
  this.config = config;
  this.Const = {
    BtnStoneType: [
      { x: 118, y: 139, r: 184, g: 163, b: 194 },
      { x: 167, y: 138, r: 164, g: 164, b: 164 },
      { x: 206, y: 138, r: 169, g: 121, b: 135 },
      { x: 256, y: 140, r: 142, g: 122, b: 162 },
      { x: 112, y: 189, r: 142, g: 149, b: 166 },
      { x: 162, y: 190, r: 71, g: 237, b: 237 },
      { x: 215, y: 187, r: 43, g: 36, b: 105 },
      { x: 257, y: 189, r: 56, g: 43, b: 37 },
      { x: 116, y: 237, r: 51, g: 37, b: 30 },
      { x: 156, y: 237, r: 64, g: 72, b: 81 },
      { x: 219, y: 238, r: 27, g: 27, b: 71 },
      { x: 266, y: 237, r: 36, g: 36, b: 69 },
      { x: 114, y: 279, r: 90, g: 84, b: 86 },
      { x: 165, y: 282, r: 20, g: 13, b: 75 },
      { x: 226, y: 286, r: 97, g: 98, b: 102 },
      { x: 260, y: 286, r: 77, g: 67, b: 78 },
    ],
    ColorTaskMining: [
      {x: 401, y: 144, r: 249, g: 248, b: 233},
      {x: 407, y: 137, r: 201, g: 169, b: 107},
      {x: 390, y: 150, r: 250, g: 244, b: 231},
      {x: 399, y: 136, r: 252, g: 244, b: 228},
      {x: 404, y: 152, r: 227, g: 210, b: 176},
    ],
    BtnLoc: { x: 380, y: 179, r: 250, g: 250, b: 251 },
    BtnExitMining: { x: 521, y: 92, r: 135, g: 122, b: 153 },
    BtnStartMining: { x: 556, y: 268, r: 219, g: 214, b: 230 },
    TryTime: 50,
  };
  this.init();
}

MiningManager.prototype.autoMining = function () {
  utils.openLiveMenu("mining");
  console.log(
    "Mining :",
    "stoneIndex ",
    this.config.stoneIndex,
    "miningTime(sec) ",
    this.config.miningTime
  );
  tap(
    this.Const.BtnStoneType[this.config.stoneIndex].x,
    this.Const.BtnStoneType[this.config.stoneIndex].y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate);
  tap(this.Const.BtnLoc.x, this.Const.BtnLoc.y, this.config.sleep);
  sleep(this.config.sleepAnimate);
  for (var i = 0; i < this.Const.TryTime; i++) {
    if (utils.isSameView(this.Const.ColorTaskMining)) {
      console.log("arrival Mine");
      break;
    }
    console.log("wait walking to Mine");
    sleep(5000);
  }
  if (i == this.Const.TryTime) {
    console.log("error can not arrival Mine");
    return;
  }
  tap(
    this.Const.ColorTaskMining[0].x,
    this.Const.ColorTaskMining[0].y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate * 3);
  if (utils.isSameView(this.Const.ColorTaskMining))
  { 
    console.log("Unable to start mining");
    return false;
  }
  tap(
    this.Const.BtnStartMining.x,
    this.Const.BtnStartMining.y,
    this.config.sleep
  );
  sleep(this.config.sleepAnimate);
  for (var i = 1; i < this.config.miningTime / 1000; i++) {
    if (i % 10 == 0) {
      console.log("mining...", i, " sec");
    }
    sleep(1000);
  }
  tap(
    this.Const.BtnExitMining.x,
    this.Const.BtnExitMining.y,
    this.config.sleep
  );
  console.log("exit mining...");
  sleep(3000);
  return false;
};

MiningManager.prototype.init = function () {
  console.log("Mining init");
};

module.exports = MiningManager;


/***/ }),

/***/ 547:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var utils = __webpack_require__(555);

function ObtainTheBlessing(config) {
  this.config = config;
  this.Const = {
    BtnToFountain: [
      { x: 160, y: 35, r: 173, g: 139, b: 79 },
      { x: 211, y: 308, r: 146, g: 165, b: 214 },
      { x: 408, y: 301, r: 184, g: 118, b: 83 },
    ],
  };
  this.isWaitBlessing = false;
  this.init();
}

ObtainTheBlessing.prototype.getIsWaitBlessing = function () {
  return this.isWaitBlessing;
};

ObtainTheBlessing.prototype.autoObtainTheBlessing = function () {
  var d = new Date();
  var hour = (d.getHours() + this.config.timezoneOffset) % 24;
  var minute = d.getMinutes();
  if ((hour === 11 || hour === 20) && minute >= 50) {
    console.log("go blessing");
    utils.closeAutoBattle(0);
    utils.checkInMainPage();
    utils.taps(this.Const.BtnToFountain);
    sleep(this.config.sleepAnimate);
    this.isWaitBlessing = true;
  } else {
    this.isWaitBlessing = false;
  }
  return this.isWaitBlessing;
};

ObtainTheBlessing.prototype.init = function () {
  console.log("ObtainTheBlessing init");
  this.isWaitBlessing = false;
};

module.exports = ObtainTheBlessing;


/***/ }),

/***/ 555:
/***/ (function(module) {

var sleepTime = 240;
var sleepAnimateTime = 800;
var sleepAttack = 8000;

// const workType = Object.freeze({"isAct":0, "notAct":1, "finish":2});

var pageMain = [
  { x: 15, y: 121, r: 245, g: 212, b: 181 },
  { x: 68, y: 25, r: 210, g: 210, b: 227 },
  { x: 40, y: 352, r: 211, g: 213, b: 223 },
  { x: 617, y: 352, r: 211, g: 213, b: 223 },
  { x: 604, y: 13, r: 227, g: 227, b: 227 },
];

var btnLiveMenu = [
  { x: 197, y: 166, r: 209, g: 198, b: 191 },
  { x: 142, y: 264, r: 202, g: 151, b: 117 },
  { x: 256, y: 265, r: 204, g: 130, b: 121 },
  { x: 458, y: 90, r: 179, g: 145, b: 124 },
  { x: 382, y: 181, r: 169, g: 120, b: 112 },
  { x: 502, y: 180, r: 143, g: 222, b: 255 },
];

var pageQuitDialog = [
  { x: 338, y: 105, r: 121, g: 110, b: 113 },
  { x: 290, y: 232, r: 223, g: 152, b: 88 },
  { x: 397, y: 232, r: 125, g: 153, b: 227 },
  { x: 448, y: 113, r: 232, g: 109, b: 148 },
  { x: 316, y: 150, r: 231, g: 231, b: 235 },
];

var btnChangeMenu = { x: 615, y: 133, r: 93, g: 143, b: 231 };
var btnOpenLiveMenu = { x: 556, y: 251, r: 209, g: 171, b: 144 };

var pageLifeIcon = [
  { x: 552, y: 260, r: 174, g: 188, b: 224 },
  { x: 563, y: 260, r: 236, g: 240, b: 248 },
  { x: 552, y: 245, r: 203, g: 162, b: 101 },
  { x: 562, y: 245, r: 161, g: 178, b: 105 },
];

var pageLifeBack = [
  {x: 595, y: 44, r: 255, g: 255, b: 255},
  {x: 604, y: 38, r: 240, g: 174, b: 182},
  {x: 606, y: 48, r: 255, g: 189, b: 195},
  {x: 603, y: 44, r: 231, g: 170, b: 187},
  {x: 595, y: 44, r: 255, g: 255, b: 255},
];

var pageToHeavy = [
  { x: 560, y: 115, r: 201, g: 107, b: 121 },
  { x: 560, y: 124, r: 191, g: 86, b: 81 },
  { x: 619, y: 128, r: 255, g: 255, b: 255 },
  { x: 621, y: 138, r: 229, g: 229, b: 229 },
  { x: 605, y: 133, r: 229, g: 236, b: 239 },
  { x: 572, y: 129, r: 247, g: 233, b: 141 },
];
var colorLoading = [
  { x: 51, y: 333, r: 31, g: 185, b: 238 },
  { x: 604, y: 329, r: 24, g: 12, b: 12 },
];

var pageChatWindow = [
  { x: 304, y: 178, r: 94, g: 143, b: 226 },
  { x: 279, y: 21, r: 102, g: 136, b: 221 },
  { x: 281, y: 23, r: 95, g: 143, b: 227 },
  { x: 26, y: 18, r: 211, g: 204, b: 211 },
  { x: 304, y: 164, r: 208, g: 207, b: 211 },
  { x: 306, y: 195, r: 208, g: 206, b: 208 },
];

var pageRunning = [
  { x: 304, y: 119, r: 238, g: 249, b: 249 },
  { x: 303, y: 120, r: 237, g: 249, b: 249 },
  { x: 299, y: 121, r: 231, g: 252, b: 254 },
  { x: 296, y: 118, r: 191, g: 242, b: 246 },
  { x: 296, y: 113, r: 197, g: 240, b: 242 },
  { x: 300, y: 120, r: 232, g: 254, b: 255 },
  { x: 300, y: 116, r: 237, g: 255, b: 255 },
  { x: 300, y: 120, r: 227, g: 253, b: 254 },
  { x: 305, y: 118, r: 193, g: 240, b: 236 },
  { x: 302, y: 120, r: 228, g: 253, b: 255 },
];

function inPageMain() {
  return isSameView(pageMain);
}

function checkColor(data, diff) {
  if (diff == undefined) {
    diff = 20;
  }
  var img = getScreenshot();
  var c = getImageColor(img, data.x, data.y);
  releaseImage(img);
  return isSameColor(c, data, diff);
}

function isSameColor(c1, c2, diff) {
  if (diff == undefined) {
    diff = 35;
  }
  if (Math.abs(c1.r - c2.r) > diff) {
    return false;
  }
  if (Math.abs(c1.g - c2.g) > diff) {
    return false;
  }
  if (Math.abs(c1.b - c2.b) > diff) {
    return false;
  }
  if (Math.abs(c1.a - c2.a) > diff) {
    return false;
  }
  return true;
}

function isSameView(views, img, check) {
  var release = false;
  if (check === undefined) {
    check = false;
  }
  if (img === undefined) {
    img = getScreenshot();
    release = true;
  }
  var whSize = getImageSize(img);
  if (whSize.width === 360) {
    releaseImage(img);
    throw new Error("ROBroken");
  }
  var isView = true;
  for (var i in views) {
    var view = views[i];
    var c = getImageColor(img, view.x, view.y);
    if (!isSameColor(view, c)) {
      isView = false;
      if (check) {
        console.log(
          "error ",
          view.x,
          ",",
          view.y,
          ",",
          view.r,
          ",",
          view.g,
          ",",
          view.b,
          ",",
          c.r,
          ",",
          c.g,
          ",",
          c.b
        );
      }
      break;
    }
  }
  if (release) {
    releaseImage(img);
  }
  return isView;
}

function isFollowing() {
  // var clockImg = getScreenshotModify(291, 106, 15, 15, 15, 15, 95);
  // var colorCount = 0;
  // for (var i = 0; i < 15; i++) {
  //   for (var j = 0; j < 15; j++) {
  //     var c = getImageColor(clockImg, i, j);
  //     if (isSameColor(c, { r: 255, g: 255, b: 245 }, 20)) colorCount++;
  //   }
  // }
  // var result = colorCount >= 20 && colorCount <= 30;
  // if (result) console.log("isFollowing");
  // releaseImage(clockImg);
  var test1 = !isStop();
  sleep(2000);
  var test2 = !isStop();
  return test1 || test2;
}

//TODO
function isLoading() {
  var result = isSameView(colorLoading);
  if (result) console.log("isFollowing");
  return result;
}

function isPowerSavingMode() {
  var colorCheckBoard = [
    { x: 261, y: 178, r: 64, g: 55, b: 60 },
    { x: 252, y: 177, r: 64, g: 55, b: 60 },
    { x: 243, y: 177, r: 64, g: 55, b: 60 },
    { x: 271, y: 180, r: 64, g: 55, b: 60 },
  ];
  return isSameView(colorCheckBoard);
}

function checkCarnivalMenu() {
  var colorMenu = [
    { x: 444, y: 18, r: 177, g: 110, b: 143 },
    { x: 485, y: 20, r: 179, g: 169, b: 169 },
    { x: 478, y: 12, r: 240, g: 232, b: 207 },
    { x: 479, y: 22, r: 236, g: 219, b: 219 },
    { x: 491, y: 22, r: 231, g: 214, b: 222 },
    { x: 447, y: 15, r: 138, g: 84, b: 128 },
  ];
  return isSameView(colorMenu);
}

function openCarnivalMenu(target) {
  var btnCarnival = [
    { x: 518, y: 24 },
    { x: 445, y: 20 },
    { x: target.x, y: target.y },
    { x: 322, y: 292 },
  ];
  var i = 0;
  if (checkCarnivalMenu()) i = 1;
  for (; i < btnCarnival.length; i++) {
    tap(btnCarnival[i].x, btnCarnival[i].y, sleepTime);
    sleep(3000);
  }
}

function openLiveMenu(type) {
  console.log("openLiveMenu :", type);
  if (!isSameView(pageLifeIcon)) {
    tap(btnChangeMenu.x, btnChangeMenu.y, sleepTime);
    sleep(sleepAnimateTime * 2);
  }
  tap(btnOpenLiveMenu.x, btnOpenLiveMenu.y, sleepTime);
  sleep(sleepAnimateTime);
  if (isSameView(pageLifeBack))
  {
    tap(pageLifeBack[0].x, pageLifeBack[0].y, sleepTime);
    sleep(sleepAnimateTime);
  }
  switch (type) {
    case "fish":
      tap(btnLiveMenu[0].x, btnLiveMenu[0].y, sleepTime);
      break;
    case "mining":
      tap(btnLiveMenu[1].x, btnLiveMenu[1].y, sleepTime);
      break;
    case "gardening":
      tap(btnLiveMenu[2].x, btnLiveMenu[2].y, sleepTime);
      break;
    case "smelt":
      tap(btnLiveMenu[3].x, btnLiveMenu[3].y, sleepTime);
      break;
    case "cooking":
      tap(btnLiveMenu[4].x, btnLiveMenu[4].y, sleepTime);
      break;
    case "make":
      tap(btnLiveMenu[5].x, btnLiveMenu[5].y, sleepTime);
      break;
  }
  sleep(sleepAnimateTime * 3);
}

function taps(data, sleepTime) {
  if (sleepTime == undefined) {
    sleepTime = 3000;
  }
  for (var i = 0; i < data.length; i++) {
    tap(data[i].x, data[i].y, sleepTime);
    sleep(sleepTime);
  }
}

function buyItems(val) {
  var targerNumber = val;
  var resultBtn = [];
  var btnOpenNumber = { x: 276, y: 226 };
  var btnNumber = [
    { x: 507, y: 178 }, // 0
    { x: 403, y: 144 }, // 1
    { x: 438, y: 144 }, // 2
    { x: 472, y: 144 }, // 3
    { x: 403, y: 178 }, // 4
    { x: 438, y: 178 }, // 5
    { x: 472, y: 178 }, // 6
    { x: 403, y: 218 }, // 7
    { x: 438, y: 218 }, // 8
    { x: 472, y: 218 }, // 9
  ];
  var btnBuy = [
    { x: 510, y: 214 }, // V
    { x: 299, y: 296 }, // buy
    { x: 600, y: 31 }, //close
  ];

  resultBtn.push(btnOpenNumber);
  var temp = [];
  while (targerNumber > 0) {
    btnIndex = targerNumber % 10;
    targerNumber = (targerNumber - btnIndex) / 10;
    temp.push(btnNumber[btnIndex]);
  }
  temp.reverse();
  for (var i = 0; i < temp.length; i++) resultBtn.push(temp[i]);
  for (var i = 0; i < btnBuy.length; i++) resultBtn.push(btnBuy[i]);
  taps(resultBtn, 1500);
}

function autoRebirth() {
  var colorRebirth = [
    { x: 452, y: 230, r: 227, g: 199, b: 178 },
    { x: 616, y: 220, r: 231, g: 213, b: 195 },
    { x: 456, y: 318, r: 226, g: 223, b: 234 },
    { x: 606, y: 318, r: 208, g: 208, b: 224 },
    { x: 509, y: 322, r: 152, g: 198, b: 240 },
    { x: 572, y: 319, r: 128, g: 153, b: 224 },
  ];
  var btnRebirth = { x: 541, y: 320 };
  if (isSameView(colorRebirth)) {
    tap(btnRebirth.x, btnRebirth.y, sleepTime);
    sleep(20000);
    return true;
  }
  return false;
}

function closeAutoBattle(delay) {
  if (delay == undefined) {
    delay = sleepAnimateTime * 30;
  }
  var colorAutoBattle = [
    { x: 404, y: 274, r: 230, g: 246, b: 251 },
    { x: 417, y: 270, r: 201, g: 233, b: 250 },
    { x: 410, y: 280, r: 115, g: 199, b: 232 },
  ];
  var btnAutoBattle = { x: 409, y: 271 };
  if (isSameView(colorAutoBattle)) {
    console.log("Battleing sleep :", delay / 1000, " sec");
    sleep(delay);
    tap(btnAutoBattle.x, btnAutoBattle.y, sleepTime);
    return true;
  }
  return false;
}

function openStudentManual() {
  var btnStudentManual = [
    { x: 518, y: 24 },
    { x: 482, y: 20 },
    { x: 504, y: 41 },
  ];
  var i = 0;
  if (checkCarnivalMenu()) i = 1;
  for (; i < btnStudentManual.length; i++) {
    tap(btnStudentManual[i].x, btnStudentManual[i].y, sleepTime);
    sleep(3000);
  }
}

function checkChatWindow() {
  if (isSameView(pageChatWindow)) {
    console.log("chatWindow close");
    tap(pageChatWindow[0].x, pageChatWindow[0].y, sleepTime);
    sleep(sleepAnimateTime);
    return true;
  }
  return false;
}

function checkQuitDialog() {
  if (isSameView(pageQuitDialog)) {
    keycode("BACK", sleepTime);
    sleep(sleepAnimateTime);
    return true;
  }
  return false;
}

function checkInMainPage() {
  for (var i = 0; i < 100; i++) {
    checkQuitDialog();
    checkChatWindow();
    if (inPageMain()) {
      return true;
    } else {
      keycode("BACK", sleepTime);
    }
    sleep(sleepAnimateTime);
  }
  return false;
}

function checkToHeavy() {
  if (isSameView(pageToHeavy)) {
    console.log("Backpack is too heavy");
    console.log("Stop Script");
    return true;
  }
  return false;
}

function makeSimpleHandler(name, page, x, y) {
  return function (img) {
    if (isSameView(page, img)) {
      console.log(name);
      tap(x, y, sleepTime);
      return true;
    }
    return false;
  };
}

function isStop() {
  var img1 = getScreenshot();
  sleep(500);
  var img2 = getScreenshot();
  var score = getIdentityScore(img1, img2);
  var isStop = false;
  if (score > 0.99) {
    isStop = true;
  } else {
    if (score > 0.96) {
      isStop = true;
    }
    if (isStop) {
      if (isSameView(pageRunning, img1) && isSameView(pageRunning, img2)) {
        isStop = false;
      }
    }
  }
  releaseImage(img1);
  releaseImage(img2);
  console.log("isStop", isStop, score);
  return isStop;
}

module.exports.sleepTime = sleepTime;
module.exports.sleepAnimateTime = sleepAnimateTime;
module.exports.sleepAttack = sleepAttack;
module.exports.isSameColor = isSameColor;
module.exports.isFollowing = isFollowing;
module.exports.isPowerSavingMode = isPowerSavingMode;
module.exports.isSameView = isSameView;
module.exports.checkColor = checkColor;
module.exports.openCarnivalMenu = openCarnivalMenu;
module.exports.checkCarnivalMenu = checkCarnivalMenu;
module.exports.taps = taps;
module.exports.buyItems = buyItems;
module.exports.autoRebirth = autoRebirth;
module.exports.closeAutoBattle = closeAutoBattle;
module.exports.isLoading = isLoading;
module.exports.inPageMain = inPageMain;
module.exports.openLiveMenu = openLiveMenu;
module.exports.openStudentManual = openStudentManual;
module.exports.checkQuitDialog = checkQuitDialog;
module.exports.checkInMainPage = checkInMainPage;
module.exports.checkToHeavy = checkToHeavy;
module.exports.checkChatWindow = checkChatWindow;
module.exports.makeSimpleHandler = makeSimpleHandler;
module.exports.isStop = isStop;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
!function() {
var FishManager = __webpack_require__(660);
var MiningManager = __webpack_require__(671);
var GardeningManager = __webpack_require__(288);
var DailyTaskManager = __webpack_require__(255);
var MainTaskManager = __webpack_require__(900);
var Lvling = __webpack_require__(698);
var CocTask = __webpack_require__(788);
var GuildTask = __webpack_require__(322);
var LoginManager = __webpack_require__(832);
var ObtainTheBlessing = __webpack_require__(547);
var utils = __webpack_require__(555);

// function safeAdd(r, n) { var d = (65535 & r) + (65535 & n); return (r >> 16) + (n >> 16) + (d >> 16) << 16 | 65535 & d } function bitRotateLeft(r, n) { return r << n | r >>> 32 - n } function md5cmn(r, n, d, t, m, f) { return safeAdd(bitRotateLeft(safeAdd(safeAdd(n, r), safeAdd(t, f)), m), d) } function md5ff(r, n, d, t, m, f, i) { return md5cmn(n & d | ~n & t, r, n, m, f, i) } function md5gg(r, n, d, t, m, f, i) { return md5cmn(n & t | d & ~t, r, n, m, f, i) } function md5hh(r, n, d, t, m, f, i) { return md5cmn(n ^ d ^ t, r, n, m, f, i) } function md5ii(r, n, d, t, m, f, i) { return md5cmn(d ^ (n | ~t), r, n, m, f, i) } function binlMD5(r, n) { var d, t, m, f, i; r[n >> 5] |= 128 << n % 32, r[14 + (n + 64 >>> 9 << 4)] = n; var e = 1732584193, h = -271733879, g = -1732584194, u = 271733878; for (d = 0; d < r.length; d += 16)t = e, m = h, f = g, i = u, e = md5ff(e, h, g, u, r[d], 7, -680876936), u = md5ff(u, e, h, g, r[d + 1], 12, -389564586), g = md5ff(g, u, e, h, r[d + 2], 17, 606105819), h = md5ff(h, g, u, e, r[d + 3], 22, -1044525330), e = md5ff(e, h, g, u, r[d + 4], 7, -176418897), u = md5ff(u, e, h, g, r[d + 5], 12, 1200080426), g = md5ff(g, u, e, h, r[d + 6], 17, -1473231341), h = md5ff(h, g, u, e, r[d + 7], 22, -45705983), e = md5ff(e, h, g, u, r[d + 8], 7, 1770035416), u = md5ff(u, e, h, g, r[d + 9], 12, -1958414417), g = md5ff(g, u, e, h, r[d + 10], 17, -42063), h = md5ff(h, g, u, e, r[d + 11], 22, -1990404162), e = md5ff(e, h, g, u, r[d + 12], 7, 1804603682), u = md5ff(u, e, h, g, r[d + 13], 12, -40341101), g = md5ff(g, u, e, h, r[d + 14], 17, -1502002290), e = md5gg(e, h = md5ff(h, g, u, e, r[d + 15], 22, 1236535329), g, u, r[d + 1], 5, -165796510), u = md5gg(u, e, h, g, r[d + 6], 9, -1069501632), g = md5gg(g, u, e, h, r[d + 11], 14, 643717713), h = md5gg(h, g, u, e, r[d], 20, -373897302), e = md5gg(e, h, g, u, r[d + 5], 5, -701558691), u = md5gg(u, e, h, g, r[d + 10], 9, 38016083), g = md5gg(g, u, e, h, r[d + 15], 14, -660478335), h = md5gg(h, g, u, e, r[d + 4], 20, -405537848), e = md5gg(e, h, g, u, r[d + 9], 5, 568446438), u = md5gg(u, e, h, g, r[d + 14], 9, -1019803690), g = md5gg(g, u, e, h, r[d + 3], 14, -187363961), h = md5gg(h, g, u, e, r[d + 8], 20, 1163531501), e = md5gg(e, h, g, u, r[d + 13], 5, -1444681467), u = md5gg(u, e, h, g, r[d + 2], 9, -51403784), g = md5gg(g, u, e, h, r[d + 7], 14, 1735328473), e = md5hh(e, h = md5gg(h, g, u, e, r[d + 12], 20, -1926607734), g, u, r[d + 5], 4, -378558), u = md5hh(u, e, h, g, r[d + 8], 11, -2022574463), g = md5hh(g, u, e, h, r[d + 11], 16, 1839030562), h = md5hh(h, g, u, e, r[d + 14], 23, -35309556), e = md5hh(e, h, g, u, r[d + 1], 4, -1530992060), u = md5hh(u, e, h, g, r[d + 4], 11, 1272893353), g = md5hh(g, u, e, h, r[d + 7], 16, -155497632), h = md5hh(h, g, u, e, r[d + 10], 23, -1094730640), e = md5hh(e, h, g, u, r[d + 13], 4, 681279174), u = md5hh(u, e, h, g, r[d], 11, -358537222), g = md5hh(g, u, e, h, r[d + 3], 16, -722521979), h = md5hh(h, g, u, e, r[d + 6], 23, 76029189), e = md5hh(e, h, g, u, r[d + 9], 4, -640364487), u = md5hh(u, e, h, g, r[d + 12], 11, -421815835), g = md5hh(g, u, e, h, r[d + 15], 16, 530742520), e = md5ii(e, h = md5hh(h, g, u, e, r[d + 2], 23, -995338651), g, u, r[d], 6, -198630844), u = md5ii(u, e, h, g, r[d + 7], 10, 1126891415), g = md5ii(g, u, e, h, r[d + 14], 15, -1416354905), h = md5ii(h, g, u, e, r[d + 5], 21, -57434055), e = md5ii(e, h, g, u, r[d + 12], 6, 1700485571), u = md5ii(u, e, h, g, r[d + 3], 10, -1894986606), g = md5ii(g, u, e, h, r[d + 10], 15, -1051523), h = md5ii(h, g, u, e, r[d + 1], 21, -2054922799), e = md5ii(e, h, g, u, r[d + 8], 6, 1873313359), u = md5ii(u, e, h, g, r[d + 15], 10, -30611744), g = md5ii(g, u, e, h, r[d + 6], 15, -1560198380), h = md5ii(h, g, u, e, r[d + 13], 21, 1309151649), e = md5ii(e, h, g, u, r[d + 4], 6, -145523070), u = md5ii(u, e, h, g, r[d + 11], 10, -1120210379), g = md5ii(g, u, e, h, r[d + 2], 15, 718787259), h = md5ii(h, g, u, e, r[d + 9], 21, -343485551), e = safeAdd(e, t), h = safeAdd(h, m), g = safeAdd(g, f), u = safeAdd(u, i); return [e, h, g, u] } function binl2rstr(r) { var n, d = "", t = 32 * r.length; for (n = 0; n < t; n += 8)d += String.fromCharCode(r[n >> 5] >>> n % 32 & 255); return d } function rstr2binl(r) { var n, d = []; for (d[(r.length >> 2) - 1] = void 0, n = 0; n < d.length; n += 1)d[n] = 0; var t = 8 * r.length; for (n = 0; n < t; n += 8)d[n >> 5] |= (255 & r.charCodeAt(n / 8)) << n % 32; return d } function rstrMD5(r) { return binl2rstr(binlMD5(rstr2binl(r), 8 * r.length)) } function rstrHMACMD5(r, n) { var d, t, m = rstr2binl(r), f = [], i = []; for (f[15] = i[15] = void 0, m.length > 16 && (m = binlMD5(m, 8 * r.length)), d = 0; d < 16; d += 1)f[d] = 909522486 ^ m[d], i[d] = 1549556828 ^ m[d]; return t = binlMD5(f.concat(rstr2binl(n)), 512 + 8 * n.length), binl2rstr(binlMD5(i.concat(t), 640)) } function rstr2hex(r) { var n, d, t = ""; for (d = 0; d < r.length; d += 1)n = r.charCodeAt(d), t += "0123456789abcdef".charAt(n >>> 4 & 15) + "0123456789abcdef".charAt(15 & n); return t } function str2rstrUTF8(r) { return unescape(encodeURIComponent(r)) } function rawMD5(r) { return rstrMD5(str2rstrUTF8(r)) } function hexMD5(r) { return rstr2hex(rawMD5(r)) } function rawHMACMD5(r, n) { return rstrHMACMD5(str2rstrUTF8(r), str2rstrUTF8(n)) } function hexHMACMD5(r, n) { return rstr2hex(rawHMACMD5(r, n)) } function md5(r, n, d) { return n ? d ? rawHMACMD5(n, r) : hexHMACMD5(n, r) : d ? rawMD5(r) : hexMD5(r) } function genkey(r, n) { var d = r + "_" + n + "_" + Math.floor(100 * Math.random()); return d + md5(md5(d + "m1gj")).substr(4, 4) } function checkKey(r) { if (md5(md5(r.substr(0, r.length - 4) + "m1gj")).substr(4, 4) !== r.substr(r.length - 4)) return !1; var n = r.split("_"); if (3 !== n.length) return !1; var d = new Date(n[1]); return !(Date.now() > d.getTime()) }

var DefaultConfig = {
  startTime: 0,
  runRoles: 0,
  region: -1, // -1 Use default
  server: 0,
  sleep: utils.sleepTime,
  sleepAnimate: utils.sleepAnimateTime,
  sleepAttack: utils.sleepAttack,
  repeatEvent: false,
  useCrystalToBuy: false,
  guildTaskUseGardening: false,
  // languageFamily: 'zh-TW',
  // timeZone: 'Asia/Taipei',
  timezoneOffset: 8,
  // Task
  isCocTask: false,
  isGuildTask: false,
  isDailyTask: false,
  cocTaskType: 0, //0: head, 1: equipment, 2: pet
  // Lvling
  isLvling: false,
  monsterIndex: 10,
  lvlingTime: 60 * 60000,
  //Fish
  isFish: true,
  baitIndex: 0,
  fishIndex: 1,
  fishTimes: 50,
  // Mining
  isMining: false,
  stoneIndex: 1,
  miningTime: 60 * 60000,
  // Gardening
  isGardening: false,
  plantIndex: 0,
  gardeningTimes: 50,
  //MainTask
  isMainTask: false,
  // ObtainTheBlessing
  isObtainTheBlessing: false,
  // checkToHeavy
  isCheckToHeavy: true,
};

var RoMScript = function (config) {
  this.init(config);
};

RoMScript.prototype.init = function (config) {
  this.config = config;
  if (this.config.sleep === undefined) {
    this.config.sleep = DefaultConfig.sleep;
  }
  if (this.config.sleepAnimateTime === undefined) {
    this.config.sleepAnimate = DefaultConfig.sleepAnimate;
  }
  if (this.config.sleepAttack === undefined) {
    this.config.sleepAttack = DefaultConfig.sleepAttack;
  }
  if (this.config.timezoneOffset === undefined) {
    this.config.timezoneOffset = DefaultConfig.timezoneOffset;
  }
  this._loop = false;
  this.eventIndex = 0;

  this.fishManager = new FishManager(this.config);
  this.miningManager = new MiningManager(this.config);
  this.gardeningManager = new GardeningManager(this.config);
  this.dailyTaskManager = new DailyTaskManager(this.config);
  this.lvlingManager = new Lvling(this.config);
  this.cocTask = new CocTask(this.config);
  this.guildTask = new GuildTask(this.config);
  this.loginManager = new LoginManager(this.config);
  this.mainTaskManager = new MainTaskManager(this.config);
  this.obtainTheBlessing = new ObtainTheBlessing(this.config);

  this.handleEvents = [];
  if (this.config.isMainTask)
    this.handleEvents.push(
      this.mainTaskManager.autoMainTask.bind(this.mainTaskManager)
    );
  if (this.config.isGuildTask)
    this.handleEvents.push(this.guildTask.autoGuildTaskV2.bind(this.guildTask));
  if (this.config.isCocTask)
    this.handleEvents.push(this.cocTask.autoCocTaskV2.bind(this.cocTask));
  if (this.config.isDailyTask)
    this.handleEvents.push(
      this.dailyTaskManager.autoDailyTask.bind(this.dailyTaskManager)
    );
  if (this.config.isFish)
    this.handleEvents.push(this.fishManager.autoFish.bind(this.fishManager));
  if (this.config.isMining)
    this.handleEvents.push(
      this.miningManager.autoMining.bind(this.miningManager)
    );
  if (this.config.isGardening)
  { 
    this.handleEvents.push(
      this.gardeningManager.autoGardening.bind(this.gardeningManager)
    );
  };
  if (this.config.isLvling)
    this.handleEvents.push(
      this.lvlingManager.autoLvling.bind(this.lvlingManager)
    );

  this.handleException = [
    utils.autoRebirth,
    utils.checkQuitDialog,
    utils.checkChatWindow,
  ];
  if (this.config.isCheckToHeavy)
  {
    this.handleException.push(
      utils.checkToHeavy
    );
  }
  if (this.config.isObtainTheBlessing)
    this.handleException.push(
      this.obtainTheBlessing.autoObtainTheBlessing.bind(this.obtainTheBlessing)
    );
};

RoMScript.prototype.start = function () {
  this.config.startTime = Date.now();
  this._loop = true;
  this.loginManager.autoLogin();
  while (this._loop) {
    console.log("run Ro Script");
    if (this.eventIndex >= this.handleEvents.length) {
      console.log("script finish");
      if (this.config.repeatEvent) {
        console.log("restart script");
        this.eventIndex = 0;
      } else {
        console.log("finish script");
        break;
      }
    }
    try {
      var isExceptionAct = false;
      for (var j = 0; j < this.handleException.length; j++) {
        var exceptionHandler = this.handleException[j];
        isExceptionAct = isExceptionAct || exceptionHandler();
      }
      if (!isExceptionAct) {
        var handler = this.handleEvents[this.eventIndex];
        var isAct = handler();
        if (!isAct) {
          sleep(this.config.sleepAnimate);
          this.eventIndex += 1;
          i = 1;
          var inMain = utils.checkInMainPage();
          if (!inMain) {
            throw new Error("can not to main page");
          }
        }
      }
    } catch (e) {
      if (e.message === "ROBroken") {
        this.loginManager.autoLogin();
      } else {
        console.log("error msg : ", e.message);
      }
    }
    sleep(this.config.sleepAnimate * 2);
  }
};

RoMScript.prototype.stop = function () {
  this._loop = false;
};

window = {};
window.start = function (config) {
  console.log("📢 啟動腳本 📢");
  if (typeof config === "string") {
    config = JSON.parse(config);
  }

  roM = new RoMScript(config);
  roM.start();
  roM.stop();
  roM = undefined;
  console.log("📢 腳本已停止 📢");
};
window.stop = function () {
  if (roM == undefined) {
    return;
  }
  roM._loop = false;
  roM = undefined;
  console.log("📢 停止腳本中 📢");
};

function stop() {
  if (roM == undefined) {
    return;
  }
  roM._loop = false;
  roM = undefined;
  console.log("📢 停止腳本中 📢");
}
// window.start(DefaultConfig);
}();
/******/ })()
;