/* prettier-ignore */ !function (e, t) { "object" == typeof exports && "object" == typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : "object" == typeof exports ? exports.RF = t() : e.RF = t() }(this, (function () { return function () { "use strict"; var e = { 607: function (e, t, r) { var o = this && this.__createBinding || (Object.create ? function (e, t, r, o) { void 0 === o && (o = r), Object.defineProperty(e, o, { enumerable: !0, get: function () { return t[r] } }) } : function (e, t, r, o) { void 0 === o && (o = r), e[o] = t[r] }), n = this && this.__exportStar || function (e, t) { for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || o(t, e, r) }; Object.defineProperty(t, "__esModule", { value: !0 }), t.version = void 0, n(r(850), t), n(r(985), t), n(r(837), t), n(r(459), t), n(r(231), t), n(r(200), t), n(r(656), t), n(r(708), t), n(r(974), t), t.version = 1 }, 850: function (e, t) { Object.defineProperty(t, "__esModule", { value: !0 }), t.GroupPage = void 0; var r = function () { function e(e, t) { this.name = e, this.pages = t } return e.prototype.isMatchImage = function (e, t) { void 0 === t && (t = .9); for (var r = [], o = 0, n = this.pages; o < n.length; o++) { var i = n[o]; i.isMatchImage(e, t) && r.push(i.name) } return r }, e.prototype.isMatchScreen = function (e, t) { void 0 === t && (t = .9); var r = e.getCvtDevScreenshot(), o = this.isMatchImage(r, t); return releaseImage(r), o }, e.prototype.waitScreenForMatchingOne = function (t, r, o, n, i) { void 0 === o && (o = 1), void 0 === n && (n = 600), void 0 === i && (i = .9), e.debug && console.log("GroupPage.waitScreenForMatchingOne " + this.name + ": " + this.pages.map((function (e) { return e.name })).join(",")); for (var s = Date.now(), a = "", c = 0; Date.now() - s < r;) { for (var f = t.getCvtDevScreenshot(), m = 0, h = this.pages; m < h.length; m++) { var g = h[m]; if (g.isMatchImage(f, i)) { a !== g.name && (a = g.name, c = 0), c++; break } } if (releaseImage(f), "" !== a && c >= o) break; sleep(n) } return e.debug && console.log("GroupPage.waitScreenForMatchingOne " + this.name + ": matched: " + a + ", usedTime " + (Date.now() - s)), a }, e.debug = !1, e }(); t.GroupPage = r }, 985: function (e, t, r) { Object.defineProperty(t, "__esModule", { value: !0 }), t.Page = void 0; var o = r(656), n = function () { function e(e, t, r, o) { void 0 === r && (r = void 0), void 0 === o && (o = void 0), this.name = e, this.points = t, this.next = r, this.back = o } return e.prototype.goNext = function (t) { void 0 !== this.next ? t.tap(this.next) : e.debug && console.log("Warning Page: " + this.name + " has no next xy") }, e.prototype.goBack = function (t) { void 0 !== this.back ? t.tap(this.back) : e.debug && console.log("Warning Page: " + this.name + " has no back xy") }, e.prototype.isMatchImage = function (e, t) { void 0 === t && (t = .9); for (var r = !0, n = 0, i = this.points; n < i.length; n++) { var s = i[n], a = getImageColor(e, s.x, s.y); if (o.Colors.identityColor(s, a) < t) { r = !1; break } } return r }, e.prototype.isMatchScreen = function (e, t) { void 0 === t && (t = .9); var r = e.getCvtDevScreenshot(), o = this.isMatchImage(r, t); return releaseImage(r), o }, e.prototype.waitScreenForMatchingScreen = function (t, r, o, n, i) { void 0 === o && (o = 1), void 0 === n && (n = 600), void 0 === i && (i = .9), e.debug && console.log("Page.waitScreenForMatchingScreen " + this.name); for (var s = Date.now(), a = 0; Date.now() - s < r && (this.isMatchScreen(t, i) && a++, !(a >= o));)sleep(n); return a >= o ? (e.debug && console.log("Page.waitScreenForMatchingScreen " + this.name + " success, usedTime " + (Date.now() - s)), !0) : (e.debug && console.log("Page.waitScreenForMatchingScreen " + this.name + " timeout"), !1) }, e.debug = !1, e }(); t.Page = n }, 837: function (e, t) { Object.defineProperty(t, "__esModule", { value: !0 }), t.XYRGB = void 0; t.XYRGB = function () { this.x = 0, this.y = 0, this.r = 0, this.g = 0, this.b = 0 } }, 459: function (e, t, r) { Object.defineProperty(t, "__esModule", { value: !0 }), t.Screen = void 0; var o = r(656), n = function () { function e(e) { this.config = e; var t = getScreenSize(); this.config.deviceHeight = t.height, this.config.deviceWidth = t.width, this.config.screenWidth = t.width, this.config.screenHeight = t.height, this.config.screenOffsetX = 0, this.config.screenOffsetY = 0 } return e.prototype.calculateDeviceOffset = function (e) { var t = e(this); this.config.screenWidth = t.screenWidth, this.config.screenHeight = t.screenHeight, this.config.screenOffsetX = t.screenOffsetX, this.config.screenOffsetY = t.screenOffsetY }, e.prototype.getScreenX = function (e) { return Math.floor(this.config.screenOffsetX + e * this.config.screenWidth / this.config.devWidth) || 0 }, e.prototype.getScreenY = function (e) { return Math.floor(this.config.screenOffsetY + e * this.config.screenHeight / this.config.devHeight) || 0 }, e.prototype.getScreenXY = function (e, t) { if (void 0 === t && (t = void 0), "object" == typeof e) return { x: this.getScreenX(e.x), y: this.getScreenY(e.y) }; if ("number" == typeof e && "number" == typeof t) return { x: this.getScreenX(e), y: this.getScreenY(t) }; throw new Error("getScreenXY wrong params " + e + ", " + t) }, e.prototype.tap = function (e, t) { if (void 0 === t && (t = void 0), "object" == typeof e) { var r = this.getScreenX(e.x), o = this.getScreenY(e.y); tap(r, o, this.config.actionDuring) } else { if ("number" != typeof e || "number" != typeof t) throw new Error("tapDown wrong params " + e + ", " + t); r = this.getScreenX(e), o = this.getScreenY(t), tap(r, o, this.config.actionDuring) } }, e.prototype.tapDown = function (e, t) { if (void 0 === t && (t = void 0), "object" == typeof e) { var r = this.getScreenX(e.x), o = this.getScreenY(e.y); tapDown(r, o, this.config.actionDuring) } else { if ("number" != typeof e || "number" != typeof t) throw new Error("tapDown wrong params " + e + ", " + t); r = this.getScreenX(e), o = this.getScreenY(t), tapDown(r, o, this.config.actionDuring) } }, e.prototype.moveTo = function (e, t) { if (void 0 === t && (t = void 0), "object" == typeof e) { var r = this.getScreenX(e.x), o = this.getScreenY(e.y); moveTo(r, o, this.config.actionDuring) } else { if ("number" != typeof e || "number" != typeof t) throw new Error("tapDown wrong params " + e + ", " + t); r = this.getScreenX(e), o = this.getScreenY(t), moveTo(r, o, this.config.actionDuring) } }, e.prototype.tapUp = function (e, t) { if (void 0 === t && (t = void 0), "object" == typeof e) { var r = this.getScreenX(e.x), o = this.getScreenY(e.y); tapUp(r, o, this.config.actionDuring) } else { if ("number" != typeof e || "number" != typeof t) throw new Error("tapDown wrong params " + e + ", " + t); r = this.getScreenX(e), o = this.getScreenY(t), tapUp(r, o, this.config.actionDuring) } }, e.prototype.getScreenColor = function (e, t) { if (void 0 === t && (t = void 0), "object" == typeof e) { var r = this.getCvtDevScreenshot(), o = getImageColor(r, e.x, e.y); return releaseImage(r), o } if ("number" == typeof e && "number" == typeof t) return r = this.getCvtDevScreenshot(), o = getImageColor(r, e, t), releaseImage(r), o; throw new Error("tapDown wrong params " + e + ", " + t) }, e.prototype.findImage = function (e) { var t = this.getCvtDevScreenshot(), r = findImage(t, e); return releaseImage(t), r }, e.prototype.tapImage = function (e) { var t = this.findImage(e); this.tap(t) }, e.prototype.isSameColor = function (e, t) { void 0 === t && (t = .9); var r = this.getScreenColor(e); return o.Colors.identityColor(r, e) > t }, e.prototype.getDeviceScreenshot = function () { return getScreenshot() }, e.prototype.getScreenScreenshot = function () { return getScreenshotModify(this.config.screenOffsetX, this.config.screenOffsetY, this.config.screenWidth, this.config.screenHeight, this.config.screenWidth, this.config.screenHeight, 100) }, e.prototype.getCvtDevScreenshot = function () { return getScreenshotModify(this.config.screenOffsetX, this.config.screenOffsetY, this.config.screenWidth, this.config.screenHeight, this.config.devWidth, this.config.devHeight, 100) }, e.prototype.setActionDuring = function (e) { this.config.actionDuring = e }, e.debug = !1, e }(); t.Screen = n }, 231: function (e, t) { Object.defineProperty(t, "__esModule", { value: !0 }), t.ScreenConfig = void 0; t.ScreenConfig = function () { this.devWidth = 640, this.devHeight = 360, this.deviceWidth = 0, this.deviceHeight = 0, this.screenWidth = 0, this.screenHeight = 0, this.screenOffsetX = 0, this.screenOffsetY = 0, this.actionDuring = 180 } }, 200: function (e, t, r) { Object.defineProperty(t, "__esModule", { value: !0 }), t.TaskManager = t.Task = void 0; var o = r(974), n = function () { this.name = "", this.runTimes = 1, this.maxRunningDuring = 0, this.minIntervalDuring = 0, this.lastRunDoneTime = 0, this.run = function () { } }; t.Task = n; var i = function () { function e() { this.isRunning = !1, this.runIdx = 0, this.tasks = [] } return e.prototype.addTask = function (e, t, r, o, i) { void 0 === r && (r = 1), void 0 === o && (o = 0), void 0 === i && (i = 0); var s = new n; s.name = e, s.run = t, s.runTimes = r, s.maxRunningDuring = o, s.minIntervalDuring = i, this.tasks.push(s) }, e.prototype.start = function () { if (0 === this.tasks.length) throw new Error("TaskManager: No tasks to run"); for (console.log("TaskManager start"), this.isRunning = !0; this.isRunning;) { var e = Date.now(), t = this.tasks[this.runIdx % this.tasks.length]; if (this.runIdx++, !(e - t.lastRunDoneTime < t.minIntervalDuring)) { console.log("RunTask " + this.runIdx + " " + t.name + ", times " + t.runTimes + ", maxDuring " + t.maxRunningDuring); for (var r = 0; this.isRunning && (console.log("TaskRunning " + t.name + ", times " + r + "/" + t.runTimes), t.run(), t.lastRunDoneTime = Date.now(), r++, !(0 !== t.runTimes && r >= t.runTimes)) && !(Date.now() - e > t.maxRunningDuring);)sleep(100) } } }, e.prototype.stop = function () { this.isRunning = !1, o.Utils.sleep(1e3), console.log("TaskManager stop") }, e }(); t.TaskManager = i }, 656: function (e, t) { Object.defineProperty(t, "__esModule", { value: !0 }), t.Colors = void 0; var r = function () { function e() { } return e.getRangeColor = function (e, t, r, o, n) { void 0 === n && (n = 5); var i = !1; void 0 === e && (i = !0, e = getScreenshot()); for (var s = getImageSize(e), a = Math.max(0, t - o), c = Math.max(0, r - o), f = Math.min(s.width, t + o), m = Math.min(s.height, r + o), h = Math.max(1, (f - a) / n), g = Math.max(1, (m - c) / n), u = 0, p = { r: 0, g: 0, b: 0 }, y = a; y < f; y += h)for (var v = c; v < m; v += g) { var l = getImageColor(e, Math.floor(y), Math.floor(v)); p.r += l.r, p.g += l.g, p.b += l.b, u++ } return i && releaseImage(e), { r: Math.floor(p.r / u), g: Math.floor(p.g / u), b: Math.floor(p.b / u) } }, e.color2hex = function (e) { return ((1 << 24) + (e.r << 16) + (e.g << 8) + e.b).toString(16).slice(1) }, e.hex2Color = function (e) { return { r: parseInt(e[0] + e[1], 16), g: parseInt(e[2] + e[3], 16), b: parseInt(e[4] + e[5], 16) } }, e.identityColor = function (e, t) { var r = (e.r + t.r) / 2, o = e.r - t.r, n = e.g - t.g, i = e.b - t.b; return 1 - Math.sqrt(((512 + r) * o * o >> 8) + 4 * n * n + ((767 - r) * i * i >> 8)) / 768 }, e }(); t.Colors = r }, 708: function (e, t) { Object.defineProperty(t, "__esModule", { value: !0 }), t.OCR = void 0; var r = function () { function e(e) { this.words = e } return e.prototype.recognize = function (e, t, r, o) { void 0 === o && (o = .8); for (var n = 0, i = [], s = 0; s < this.words.length; s++) { var a = this.words[s], c = getImageSize(a.img); n = Math.max(n, c.width); var f = findImages(e, a.img, r, t, !0); for (var m in f) { var h = f[m]; i.push({ char: a.char, x: h.x, y: h.y, score: h.score, w: c.width }) } } i.sort((function (e, t) { return e.x - t.x })); for (var g = "", u = 0, p = 0, y = 0; y < i.length; y++) { var v = i[y]; v.x > u ? (p = v.score, g += v.char, u = Math.floor(v.x + v.w * o)) : v.x <= u && v.score > p && " " !== v.char && (p = v.score, g = g.substr(0, g.length - 1) + v.char, u = Math.floor(v.x + v.w * o)) } return g }, e }(); t.OCR = r }, 974: function (e, t) { var r = this && this.__spreadArray || function (e, t) { for (var r = 0, o = t.length, n = e.length; r < o; r++, n++)e[n] = t[r]; return e }; Object.defineProperty(t, "__esModule", { value: !0 }), t.Utils = t.log = void 0, t.log = function () { for (var e = [], t = 0; t < arguments.length; t++)e[t] = arguments[t]; for (var r = (new Date).toLocaleString("en-US", { timeZone: "Asia/Taipei" }), o = "[" + r + "] ", n = 0, i = e; n < i.length; n++) { var s = i[n]; o += "object" == typeof s ? JSON.stringify(s) + " " : s + " " } console.log(o.substr(0, o.length - 1)) }; var o = function () { function e() { } return e.sortStringNumberMap = function (e) { var t = []; for (var r in e) t.push({ key: r, count: e[r] }); return t.sort((function (e, t) { return t.count - e.count })), t }, e.sleep = function (e) { for (; e > 200;)e -= 200, sleep(200); e > 0 && sleep(e) }, e.getTaiwanTime = function () { return Date.now() + 288e5 }, e.log = function () { for (var t = [], o = 0; o < arguments.length; o++)t[o] = arguments[o]; for (var n = 0; n < t.length; n++) { var i = t[n]; "object" == typeof i && (t[n] = JSON.stringify(i)) } var s = new Date(e.getTaiwanTime()), a = "[" + (s.getMonth() + 1) + "-" + s.getDate() + "T" + s.getHours() + ":" + s.getMinutes() + ":" + s.getSeconds() + "]"; console.log.apply(console, r([a], t)) }, e.notifyEvent = function (t, r) { null != sendEvent && (e.log("sendEvent", t, r), sendEvent("" + t, "" + r)) }, e.startApp = function (e) { execute("BOOTCLASSPATH=/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar am start -n " + e), execute("ANDROID_DATA=/data BOOTCLASSPATH=/system/framework/core-oj.jar:/system/framework/core-libart.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/ims-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/apache-xml.jar:/system/framework/org.apache.http.legacy.boot.jar am start -n " + e) }, e.stopApp = function (e) { execute("BOOTCLASSPATH=/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar am force-stop " + e), execute("ANDROID_DATA=/data BOOTCLASSPATH=/system/framework/core-oj.jar:/system/framework/core-libart.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/ims-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/apache-xml.jar:/system/framework/org.apache.http.legacy.boot.jar am force-stop " + e) }, e.getCurrentApp = function () { for (var e = "", t = "", r = 0, o = execute("dumpsys activity top").split("\n"); r < o.length; r++) { var n = o[r], i = n.indexOf("ACTIVITY"); if (-1 !== i) { e = "", t = ""; for (var s = !0, a = i + 9; a < n.length; a++) { var c = n[a]; if (" " === c) break; "/" === c ? s = !1 : s ? e += c : t += c } } } return [e, t] }, e }(); t.Utils = o } }, t = {}; return function r(o) { var n = t[o]; if (void 0 !== n) return n.exports; var i = t[o] = { exports: {} }; return e[o].call(i.exports, i, i.exports, r), i.exports }(607) }() }));

RF.Page.debug = true;
RF.GroupPage.debug = true;
RF.Screen.debug = true;

var defaultConfig = {
  trial: false,
  watchAD: false,
  enablePVP: true,
  enableCoOp: true,
};

function RushRoyale(config) {
  this.screenConfig = new RF.ScreenConfig();
  this.screenConfig.devWidth = 360;
  this.screenConfig.devHeight = 640;
  this.screenConfig.actionDuring = 26;

  this.config = {
    trial: config.trial,
    watchAD: config.watchAD,
    enablePVP: config.enablePVP,
    enableCoOp: config.enableCoOp,
  };
  this.screen = new RF.Screen(this.screenConfig);
  this.taskManager = new RF.TaskManager();
  this.running = false;
  this.doTrial = false;

  if (this.config.trial) {
    this.taskManager.addTask('taskTrial', this.taskTrial.bind(this), 1, 0, 60 * 60 * 1000);
  }
  if (this.config.enablePVP) {
    console.log('taskBattlePVP');
    this.taskManager.addTask('taskBattlePVP', this.taskBattlePVP.bind(this));
  }
  if (this.config.enableCoOp) {
    console.log('taskBattleCoOp');
    this.taskManager.addTask('taskBattleCoOp', this.taskBattleCoOp.bind(this));
  }
}

var gMainStorePage = new RF.Page(
  'gMainStorePage',
  [
    { x: 82, y: 630, r: 0, g: 160, b: 244 },
    { x: 150, y: 628, r: 0, g: 91, b: 157 },
    { x: 215, y: 632, r: 0, g: 90, b: 158 },
    { x: 280, y: 631, r: 0, g: 90, b: 158 },
  ],
  { x: 0, y: 0 },
  { x: 0, y: 0 }
);
var gMainCardsPage = new RF.Page(
  'gMainCardsPage',
  [
    { x: 56, y: 631, r: 0, g: 90, b: 158 },
    { x: 150, y: 630, r: 0, g: 160, b: 244 },
    { x: 216, y: 631, r: 0, g: 90, b: 158 },
    { x: 279, y: 631, r: 0, g: 90, b: 158 },
  ],
  { x: 0, y: 0 },
  { x: 0, y: 0 }
);
var gMainBattlePage = new RF.Page(
  'gMainBattlePage',
  [
    { x: 54, y: 630, r: 0, g: 91, b: 157 },
    { x: 118, y: 631, r: 0, g: 90, b: 158 },
    { x: 217, y: 630, r: 0, g: 166, b: 254 },
    { x: 281, y: 630, r: 0, g: 91, b: 157 },
    { x: 147, y: 501, r: 255, g: 173, b: 0 },
    { x: 317, y: 501, r: 32, g: 129, b: 247 },
  ],
  { x: 0, y: 0 },
  { x: 0, y: 0 }
);
var gMainClanPage = new RF.Page(
  'gMainClanPage',
  [
    { x: 55, y: 632, r: 0, g: 90, b: 158 },
    { x: 120, y: 632, r: 0, g: 90, b: 158 },
    { x: 185, y: 631, r: 0, g: 90, b: 158 },
    { x: 281, y: 632, r: 0, g: 160, b: 245 },
    { x: 343, y: 628, r: 255, g: 173, b: 0 },
  ],
  { x: 0, y: 0 },
  { x: 0, y: 0 }
);
var gMainEventPage = new RF.Page(
  'gMainEventPage',
  [
    { x: 55, y: 630, r: 0, g: 91, b: 157 },
    { x: 117, y: 631, r: 0, g: 90, b: 158 },
    { x: 183, y: 631, r: 0, g: 90, b: 158 },
    { x: 247, y: 631, r: 0, g: 90, b: 158 },
    { x: 344, y: 628, r: 0, g: 160, b: 242 },
  ],
  { x: 0, y: 0 },
  { x: 0, y: 0 }
);

var gBattleFinishContinuePage1 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 115, y: 238, r: 215, g: 30, b: 24 },
    { x: 240, y: 241, r: 210, g: 28, b: 24 },
    { x: 118, y: 332, r: 40, g: 115, b: 239 },
    { x: 242, y: 335, r: 40, g: 106, b: 239 },
    { x: 237, y: 550, r: 125, g: 72, b: 60 },
    { x: 241, y: 189, r: 125, g: 72, b: 60 },
    { x: 212, y: 590, r: 40, g: 118, b: 239 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleFinishContinuePage2 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 115, y: 238, r: 40, g: 106, b: 239 },
    { x: 240, y: 241, r: 40, g: 106, b: 239 },
    { x: 118, y: 332, r: 215, g: 30, b: 24 },
    { x: 242, y: 335, r: 215, g: 30, b: 24 },
    { x: 237, y: 550, r: 125, g: 72, b: 60 },
    { x: 241, y: 189, r: 125, g: 72, b: 60 },
    { x: 212, y: 590, r: 40, g: 118, b: 239 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleFinishContinuePage3 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 80, y: 67, r: 138, g: 42, b: 44 },
    { x: 76, y: 199, r: 138, g: 42, b: 44 },
    { x: 76, y: 353, r: 40, g: 54, b: 166 },
    { x: 76, y: 482, r: 40, g: 54, b: 166 },
    { x: 316, y: 194, r: 138, g: 42, b: 44 },
    { x: 314, y: 450, r: 40, g: 54, b: 166 },
    { x: 229, y: 586, r: 38, g: 113, b: 230 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleFinishContinuePage4 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 87, y: 295, r: 24, g: 82, b: 215 },
    { x: 116, y: 295, r: 40, g: 122, b: 239 },
    { x: 242, y: 293, r: 40, g: 127, b: 239 },
    { x: 192, y: 193, r: 121, g: 70, b: 56 },
    { x: 193, y: 553, r: 123, g: 70, b: 58 },
    { x: 215, y: 595, r: 40, g: 118, b: 239 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleFinishContinuePage5 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 111, y: 132, r: 40, g: 122, b: 239 },
    { x: 245, y: 133, r: 40, g: 117, b: 239 },
    { x: 130, y: 592, r: 255, g: 255, b: 255 },
    { x: 234, y: 593, r: 38, g: 113, b: 230 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleVictoryPage = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 115, y: 42, r: 40, g: 117, b: 239 },
    { x: 239, y: 42, r: 40, g: 115, b: 239 },
    { x: 130, y: 593, r: 255, g: 255, b: 255 },
    { x: 160, y: 593, r: 40, g: 118, b: 239 },
    { x: 233, y: 593, r: 40, g: 118, b: 239 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleDefeatPage = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 115, y: 40, r: 213, g: 30, b: 24 },
    { x: 239, y: 42, r: 211, g: 28, b: 24 },
    { x: 76, y: 189, r: 0, g: 71, b: 200 },
    { x: 299, y: 187, r: 0, g: 77, b: 209 },
    { x: 230, y: 588, r: 38, g: 113, b: 230 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleDefeatPage2 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 87, y: 295, r: 179, g: 0, b: 0 },
    { x: 126, y: 295, r: 212, g: 30, b: 24 },
    { x: 249, y: 295, r: 212, g: 29, b: 24 },
    { x: 197, y: 193, r: 121, g: 70, b: 56 },
    { x: 194, y: 554, r: 121, g: 70, b: 56 },
    { x: 217, y: 592, r: 40, g: 118, b: 239 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleDefeatPage3 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 120, y: 133, r: 211, g: 28, b: 24 },
    { x: 249, y: 132, r: 212, g: 29, b: 24 },
    { x: 130, y: 592, r: 255, g: 255, b: 255 },
    { x: 232, y: 593, r: 40, g: 118, b: 239 },
    { x: 159, y: 592, r: 40, g: 118, b: 239 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleDefeatPage4 = new RF.Page(
  'gBattleFinishContinuePage',
  [
    { x: 124, y: 42, r: 211, g: 28, b: 24 },
    { x: 242, y: 42, r: 211, g: 28, b: 24 },
    { x: 272, y: 42, r: 179, g: 0, b: 0 },
    { x: 232, y: 591, r: 38, g: 113, b: 230 },
    { x: 130, y: 592, r: 255, g: 255, b: 255 },
  ],
  { x: 180, y: 590 },
  { x: 0, y: 0 }
);

var gBattleAttention = new RF.Page(
  'gBattleAttention',
  [
    { x: 82, y: 272, r: 81, g: 108, b: 146 },
    { x: 277, y: 272, r: 81, g: 108, b: 146 },
    { x: 322, y: 268, r: 255, g: 255, b: 255 },
    { x: 282, y: 360, r: 40, g: 118, b: 239 },
    { x: 162, y: 359, r: 190, g: 76, b: 227 },
  ],
  { x: 280, y: 360 },
  { x: 0, y: 0 }
);

var gSupportChest = new RF.Page(
  'gSupportChest',
  [
    { x: 79, y: 206, r: 81, g: 108, b: 146 },
    { x: 277, y: 210, r: 81, g: 108, b: 146 },
    { x: 57, y: 299, r: 227, g: 239, b: 243 },
    { x: 306, y: 547, r: 81, g: 108, b: 146 },
    { x: 161, y: 543, r: 40, g: 118, b: 239 },
    { x: 265, y: 551, r: 190, g: 76, b: 227 },
  ],
  { x: 240, y: 540 }, // watch ad
  { x: 130, y: 540 } // continue
);

var gBattleGoWaitingPage = new RF.Page(
  'gBattleGoWaitingPage',
  [
    { x: 100, y: 170, r: 195, g: 52, b: 162 },
    { x: 270, y: 170, r: 195, g: 52, b: 162 },
    { x: 150, y: 590, r: 251, g: 82, b: 56 },
    { x: 180, y: 124, r: 150, g: 215, b: 237 },
  ],
  { x: 0, y: 0 },
  { x: 0, y: 0 }
);

var gBattlePVPPage = new RF.Page(
  'gBattlePVPPage',
  [
    { x: 4, y: 567, r: 138, g: 82, b: 66 },
    { x: 4, y: 633, r: 94, g: 51, b: 40 },
    { x: 68, y: 556, r: 0, g: 224, b: 255 },
    { x: 353, y: 635, r: 86, g: 44, b: 36 },
    { x: 289, y: 632, r: 93, g: 50, b: 40 },
    { x: 278, y: 550, r: 255, g: 255, b: 255 },
  ],
  { x: 0, y: 0 },
  { x: 0, y: 0 }
);

var gBattleSeleteCoOpPage = new RF.Page(
  'gBattleSeleteCoOpPage',
  [
    { x: 100, y: 145, r: 161, g: 95, b: 71 },
    { x: 256, y: 148, r: 161, g: 95, b: 71 },
    { x: 215, y: 428, r: 255, g: 181, b: 0 },
    { x: 35, y: 603, r: 255, g: 255, b: 255 },
    { x: 182, y: 629, r: 166, g: 96, b: 73 },
    { x: 349, y: 604, r: 174, g: 100, b: 73 },
  ],
  { x: 210, y: 430 },
  { x: 0, y: 0 }
);

var gAllGroupPages = new RF.GroupPage('AllPage', [
  gMainStorePage,
  gMainCardsPage,
  gMainBattlePage,
  gMainClanPage,
  gMainEventPage,
  gBattleGoWaitingPage,
  gBattleFinishContinuePage1,
  gBattleFinishContinuePage2,
  gBattleFinishContinuePage3,
  gBattleFinishContinuePage4,
  gBattleFinishContinuePage5,
  gBattleVictoryPage,
  gBattleDefeatPage,
  gBattleDefeatPage2,
  gBattleDefeatPage3,
  gBattleDefeatPage4,
  gBattleSeleteCoOpPage,
  gBattleAttention,
  gBattlePVPPage,
  gSupportChest,
]);

var gBattleGoPvPBtn = { x: 149, y: 502, r: 255, g: 174, b: 0 };
var gBattleGoCoOpBtn = { x: 317, y: 506, r: 36, g: 131, b: 247 };
var gBattleCanBuyRoleBtn = { x: 220, y: 550, r: 254, g: 175, b: 55 };
var gBattleNotBuyRoleBtn = { x: 220, y: 550, r: 185, g: 185, b: 185 };
var gBattleCanUpgradeColors = [
  { x: 21, y: 628, r: 0, g: 249, b: 255 },
  { x: 76, y: 628, r: 0, g: 253, b: 255 },
  { x: 132, y: 628, r: 0, g: 246, b: 255 },
  { x: 187, y: 628, r: 0, g: 251, b: 255 },
  { x: 242, y: 628, r: 0, g: 253, b: 255 },
];
var gBattleNotUpgradeColors = [
  { x: 21, y: 628, r: 175, g: 175, b: 175 },
  { x: 76, y: 628, r: 177, g: 177, b: 177 },
  { x: 132, y: 628, r: 174, g: 174, b: 174 },
  { x: 187, y: 628, r: 176, g: 176, b: 176 },
  { x: 242, y: 628, r: 177, g: 177, b: 177 },
];
var gBattleUpgradeBtns = [
  { x: 32, y: 600, r: 255, g: 200, b: 158 },
  { x: 86, y: 600, r: 255, g: 120, b: 44 },
  { x: 142, y: 600, r: 217, g: 70, b: 30 },
  { x: 200, y: 600, r: 61, g: 204, b: 82 },
  { x: 254, y: 600, r: 127, g: 87, b: 58 },
];
var gBattleCanSkillBtn = { x: 332, y: 612, r: 255, g: 170, b: 0 };
var gBattleNotSkillBtn = { x: 332, y: 612, r: 48, g: 26, b: 24 };
var gBattleTableStart = { x: 64, y: 379 };
var gBattleBoxWidth = 46;
var gBattleBorderWidth = 1;
var gBattleTableBtns = [
  [
    { x: 80, y: 400 },
    { x: 130, y: 400 },
    { x: 180, y: 400 },
    { x: 230, y: 400 },
    { x: 280, y: 400 },
  ],
  [
    { x: 80, y: 450 },
    { x: 130, y: 450 },
    { x: 180, y: 450 },
    { x: 230, y: 450 },
    { x: 280, y: 450 },
  ],
  [
    { x: 80, y: 500 },
    { x: 130, y: 500 },
    { x: 180, y: 500 },
    { x: 230, y: 500 },
    { x: 280, y: 500 },
  ],
];

RushRoyale.prototype.start = function () {
  this.taskManager.start();
}

RushRoyale.prototype.stop = function () {
  this.taskManager.stop();
}

RushRoyale.prototype.taskTrial = function () {
  if (!this.doTrial) {
    console.log('Trial Version 1 Hour Start');
    this.doTrial = true;
    return;
  }
  while (true) {
    console.log('Trial Version Got Limit');
    RF.Utils.sleep(10 * 1000);
  }
}

RushRoyale.prototype.taskBattlePVP = function () {
  this.battleStart(false);
}

RushRoyale.prototype.taskBattleCoOp = function () {
  this.battleStart(true);
}

RushRoyale.prototype.battleStart = function (isCoOp) {
  if (!this.goBattlePVPCoOpPage(isCoOp)) {
    console.log('battle failed, not in PVP/CoOp page');
    return false;
  }
  for (var t = 0; t < 900; t++) {
    console.log('battle runTimes', t);
    RF.Utils.sleep(1000);
    var pages = gAllGroupPages.isMatchScreen(this.screen);
    if (pages.indexOf('gBattleFinishContinuePage') !== -1) {
      console.log('battle finished');
      this.goBattlePage();
      return true;
    }
    // check and buy roles
    if (this.screen.isSameColor(gBattleCanBuyRoleBtn)) {
      console.log('battle buy role, continue');
      this.screen.tap(gBattleCanBuyRoleBtn);
      continue;
    }
    // check is there empty grass
    var tableRoles = this.battleGetTableRoles();
    // if (this.battleHasGrass(tableRoles)) {
    //   console.log('battle has grass, continue');
    //   continue;
    // }

    // upgrade roles
    if (this.battleUpgradeRoles()) {
      continue;
    }
    // use skill
    if (this.screen.isSameColor(gBattleCanSkillBtn)) {
      this.screen.tap({ x: 320, y: 590 }); // skill btn
      continue;
    }
    if (t % 3 === 0) {
      // merge roles
      this.battleMergeRoles(tableRoles);
    }
    // merge roles
    RF.Utils.sleep(1000);
  }
};

RushRoyale.prototype.battleMergeRoles = function (tableRoles) {
  var mergeTimes = 0;
  var sy = Math.floor(Math.random() * 3);
  var sx = Math.floor(Math.random() * 5);
  var sy2 = Math.floor(Math.random() * 1);
  var sx2 = Math.floor(Math.random() * 2);
  for (var y1 = sy; y1 < 3; y1++) {
    for (var x1 = sx; x1 < 5; x1++) {
      for (var y2 = sy2; y2 < 3; y2++) {
        for (var x2 = sx2; x2 < 5; x2++) {
          if (y1 === y2 && x1 === x2) {
            continue;
          }
          var role1 = tableRoles[y1][x1];
          var role2 = tableRoles[y2][x2];
          if (role1 !== role2) {
            continue;
          }
          // merge it
          var p1 = gBattleTableBtns[y1][x1];
          var p2 = gBattleTableBtns[y2][x2];
          console.log('battle merge', y1, x1, '=>', y2, x2);
          this.screen.tapDown(p2);
          RF.Utils.sleep(400);
          this.screen.moveTo(p2);
          RF.Utils.sleep(400);
          this.screen.moveTo(p1);
          RF.Utils.sleep(400);
          this.screen.tapUp(p1);
          RF.Utils.sleep(1000);
          mergeTimes++;
          return true;
        }
      }
    }
  }
  return false;
};

RushRoyale.prototype.battleUpgradeRoles = function () {
  for (var i = 0; i < 5; i++) {
    var canUpgradeColor = gBattleCanUpgradeColors[i];
    if (this.screen.isSameColor(canUpgradeColor)) {
      console.log('Can upgrade role', i);
      this.screen.tap(gBattleUpgradeBtns[i]);
      return true;
    }
  }
  return false;
};

RushRoyale.prototype.battleHasGrass = function (tableRoles) {
  for (var y = 0; y < 3; y++) {
    for (var x = 0; x < 5; x++) {
      if (tableRoles[y][x] === -1) {
        return true;
      }
    }
  }
  return false;
};

RushRoyale.prototype.battleGetTableRoles = function () {
  var tableAvgColors = this.battleGetTableAvgColors();
  var tableRoles = this.battleClassifyTableColors2Roles(tableAvgColors);
  return tableRoles;
};

RushRoyale.prototype.battleGetTableAvgColors = function () {
  var img = this.screen.getCvtDevScreenshot();
  convertColor(img, 40);
  smooth(img, 1, 17);
  var startX = 64;
  var startY = 379;
  var boxWidth = 46;
  var boxBorder = 1;
  var points = [10, 16, 22, 30, 36];
  var tableColors = [];
  for (var y = 0; y < 3; y++) {
    tableColors.push([]);
    for (var x = 0; x < 5; x++) {
      var avgRGB = { r: 0, g: 0, b: 0 };
      for (var xp = 0; xp < 5; xp++) {
        for (var yp = 0; yp < 5; yp++) {
          var px = startX + boxWidth * x + boxBorder * (x + 1) + points[xp];
          var py = startY + boxWidth * y + boxBorder * (y + 1) + points[yp];
          var color = getImageColor(img, px, py);
          avgRGB.r += color.r;
          avgRGB.g += color.g;
          avgRGB.b += color.b;
        }
      }
      avgRGB.r /= 25;
      avgRGB.g /= 25;
      avgRGB.b /= 25;
      var r = avgRGB.r;
      var g = avgRGB.g;
      var b = avgRGB.b;
      // console.log('{ x: ' + x + ', y: ' + y + ', r: ' + r + ', g: ' + g + ', b: ' + b + ' },');
      tableColors[y].push({ r: r, g: g, b: b });
    }
  }
  releaseImage(img);
  return tableColors;
};

RushRoyale.prototype.battleClassifyTableColors2Roles = function (tableColors) {
  var roleColors = [];
  var tableRoles = [
    [-1, -1, -1, -1, -1],
    [-1, -1, -1, -1, -1],
    [-1, -1, -1, -1, -1],
  ];
  for (var y = 0; y < 3; y++) {
    tableRoles.push([]);
    for (var x = 0; x < 5; x++) {
      var avgColor = tableColors[y][x];
      var isGrass = this.battleIsGreenGrass(avgColor);
      if (isGrass) {
        continue;
      }
      var maxScore = 0;
      var maxRole = -1;
      for (var i = 0; i < roleColors.length; i++) {
        var score = RF.Colors.identityColor(avgColor, roleColors[i]);
        if (score > maxScore) {
          maxScore = score;
          maxRole = i;
        }
      }
      // console.log(maxRole, 'vs', x + ',' + y, maxScore);
      if (maxScore > 0.97) {
        tableRoles[y][x] = maxRole;
      } else {
        roleColors.push(avgColor);
        tableRoles[y][x] = roleColors.length - 1;
      }
    }
  }
  return tableRoles;
};

RushRoyale.prototype.battleIsGreenGrass = function (color) {
  if (color.r > 225 || color.r < 140) {
    return false;
  }
  if (color.g > 215 || color.g < 155) {
    return false;
  }
  if (color.b > 40 || color.b < 30) {
    return false;
  }
  return true;
};

RushRoyale.prototype.goBattlePVPCoOpPage = function (isCoOp) {
  if (gBattlePVPPage.isMatchScreen(this.screen)) {
    console.log('goBattlePVPCoOpPage success');
    return true;
  }
  this.goBattlePage();
  console.log('going Battle PVP/CoOp Page');
  if (isCoOp) {
    this.screen.tap(gBattleGoCoOpBtn);
  } else {
    this.screen.tap(gBattleGoPvPBtn);
  }
  for (var i = 0; i < 60; i++) {
    if (gBattlePVPPage.isMatchScreen(this.screen)) {
      console.log('goBattlePVPCoOpPage success');
      return true;
    } else if (gBattleSeleteCoOpPage.isMatchScreen(this.screen)) {
      console.log('goBattleCoOpPage goNext');
      gBattleSeleteCoOpPage.goNext(this.screen);
      RF.Utils.sleep(1000);
      this.screen.tap({ x: 200, y: 415 });
    }
    RF.Utils.sleep(1000);
  }
  console.log('goBattlePVPCoOpPage failed');
  return false;
};

RushRoyale.prototype.watchAD = function () {
  if (!this.config.watchAD) {
    console.log('skip AD');
    gSupportChest.goBack(this.screen);
    return;
  }
  console.log('watching AD');
  gSupportChest.goNext(this.screen);
  RF.Utils.sleep(90 * 1000);
  console.log('watching AD done, back');
  for (var i = 0; i < 5; i++) {
    this.screen.tap({ x: 340, y: 13 });
    RF.Utils.sleep(1000);
    this.screen.tap({ x: 330, y: 24 });
    RF.Utils.sleep(1000);
    this.screen.tap({ x: 340, y: 34 });
    keycode('KEYCODE_BACK', 200);
    RF.Utils.sleep(1000);
  }
};

RushRoyale.prototype.goBattlePage = function () {
  var matchTimes = 0;
  for (var i = 0; i < 20; i++) {
    RF.Utils.sleep(2000);
    var pages = gAllGroupPages.isMatchScreen(this.screen);
    if (pages.length === 0) {
      console.log('goBattlePage -> UnknownPage, Not in gAllGroupPages');
      keycode('KEYCODE_BACK', 200);
      continue;
    }
    var currentPage = pages[0];
    console.log('goBattlePage -> currentPage', currentPage, matchTimes);
    if (currentPage === 'gMainBattlePage') {
      matchTimes++;
    } else {
      matchTimes = 0;
      if (currentPage === 'gBattleFinishContinuePage') {
        gBattleFinishContinuePage1.goNext(this.screen);
      } else if (currentPage === 'gBattleAttention') {
        gBattleAttention.goNext(this.screen);
      } else if (currentPage === 'gSupportChest') {
        this.watchAD();
      } else {
        keycode('KEYCODE_BACK', 200);
      }
    }
    if (matchTimes > 3) {
      console.log('goBattlePage success');
      return true;
    }
  }
  console.log('goBattlePage failed');
  return false;
};

var rushRoyale = undefined;

function start(configJSON) {
  console.log('config', configJSON);
  var config = defaultConfig;
  if (configJSON !== undefined) {
    config = JSON.parse(configJSON);
  }
  rushRoyale = new RushRoyale(config);
  rushRoyale.start();
}

function stop() {
  if (rushRoyale !== undefined) {
    rushRoyale.stop();
  }
}
// start('{"trial":true,"watchAD":false,"enablePVP":true,"enableCoOp":true}')
